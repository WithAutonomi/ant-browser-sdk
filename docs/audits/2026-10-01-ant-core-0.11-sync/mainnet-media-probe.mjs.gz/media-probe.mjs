// Mainnet probe: openFile() range reads and <video> playback through createMediaSource().
// usage: node media-probe.mjs <SDK dist directory> <label>
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { resolve, sep } from "node:path";
import { chromium } from "./ant-client/ant-core/browser-tests/node_modules/playwright/index.mjs";

const [rootArg, label = "candidate"] = process.argv.slice(2);
const root = resolve(rootArg);
const address = "134e4537ad1b2e29f0dc48f8e025a560989e91055ebf1c66bca2208ca8bba889";
const PLAY_SECONDS = 60;
const AFTER_SEEK_SECONDS = 45;
const LIMIT_SECONDS = 360;

const types = { ".js": "text/javascript", ".wasm": "application/wasm", ".html": "text/html" };
const server = createServer(async (req, res) => {
  const pathname = new URL(req.url, "http://localhost").pathname;
  if (pathname === "/") {
    res.setHeader("Content-Type", "text/html");
    res.end('<!doctype html><title>Media probe</title><video id="v" muted playsinline></video>');
    return;
  }
  // The packaged worker must be served from the page root to control the stream URL scope.
  const path = pathname === "/autonomi-stream-sw.js" ? resolve(root, "autonomi-stream-sw.js") : resolve(root, "." + pathname.replace(/^\/sdk/, ""));
  if (!path.startsWith(root + sep)) { res.writeHead(403).end(); return; }
  try {
    const bytes = await readFile(path);
    res.setHeader("Content-Type", types[path.slice(path.lastIndexOf("."))] ?? "application/octet-stream");
    res.end(bytes);
  } catch (error) { res.writeHead(404).end(String(error)); }
});
await new Promise((done) => server.listen(0, "127.0.0.1", done));

const browser = await chromium.launch({ headless: true, args: ["--autoplay-policy=no-user-gesture-required"] });
try {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("console", (message) => { if (message.type() === "error") errors.push(`console: ${message.text()}`); });
  await page.exposeFunction("probe", (event) => console.log(JSON.stringify({ label, ...event })));
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  const run = page.evaluate(async ({ address, PLAY_SECONDS, AFTER_SEEK_SECONDS }) => {
    const t0 = performance.now();
    const at = () => Math.round(performance.now() - t0) / 1000;
    const log = (event) => globalThis.probe({ t: at(), ...event });
    const { AutonomiClient } = await import("/sdk/index.js");
    const client = await AutonomiClient.connect();
    log({ kind: "connected" });
    try {
      // Ordinary reader: header, middle and tail reads.
      const reader = await client.openFile(address);
      log({ kind: "opened", name: reader.name, size: reader.size, contentType: reader.contentType });
      for (const [what, start] of [["head", 0], ["middle", Math.floor(reader.size / 2)], ["tail", reader.size - 65_536]]) {
        const started = performance.now();
        const bytes = await reader.read(start, 65_536);
        log({ kind: "read", what, start, bytes: bytes.byteLength, ms: Math.round(performance.now() - started) });
      }
      reader.close();

      // Media source: real playback, then a seek to the middle.
      const video = document.getElementById("v");
      const stalls = [];
      let waitingSince;
      video.addEventListener("waiting", () => { waitingSince = performance.now(); });
      video.addEventListener("playing", () => {
        if (waitingSince !== undefined) stalls.push({ at: at(), ms: Math.round(performance.now() - waitingSince), position: video.currentTime });
        waitingSince = undefined;
      });
      const source = await client.createMediaSource(address);
      log({ kind: "media-source", url: source.url.slice(0, 80) });
      video.src = source.url;
      const started = performance.now();
      await video.play();
      await new Promise((done, fail) => {
        if (video.currentTime > 0) done();
        video.addEventListener("timeupdate", () => { if (video.currentTime > 0) done(); });
        video.addEventListener("error", () => fail(new Error(`media error ${video.error?.code}: ${video.error?.message}`)));
      });
      log({ kind: "first-frame", ms: Math.round(performance.now() - started) });
      const buffered = () => Array.from({ length: video.buffered.length }, (_, i) => [video.buffered.start(i), video.buffered.end(i)].map((value) => Math.round(value * 10) / 10));
      const sample = async (seconds, phase) => {
        for (let i = 0; i < seconds / 5; i++) {
          await new Promise((done) => setTimeout(done, 5_000));
          log({ kind: "sample", phase, position: Math.round(video.currentTime * 10) / 10, buffered: buffered(), readyState: video.readyState, error: video.error?.code });
        }
      };
      await sample(PLAY_SECONDS, "start");
      const beforeSeek = video.currentTime;
      const target = video.duration / 2;
      const seekStarted = performance.now();
      video.currentTime = target;
      await new Promise((done) => video.addEventListener("seeked", done, { once: true }));
      log({ kind: "seeked", target: Math.round(target), ms: Math.round(performance.now() - seekStarted) });
      await sample(AFTER_SEEK_SECONDS, "after-seek");
      log({ kind: "complete", duration: video.duration, playedBeforeSeek: beforeSeek, playedAfterSeek: video.currentTime - target, stalls, error: video.error?.code ?? null });
      source.close();
    } finally {
      client.close();
    }
  }, { address, PLAY_SECONDS, AFTER_SEEK_SECONDS });
  const limit = new Promise((_, fail) => setTimeout(() => fail(new Error(`limit ${LIMIT_SECONDS}s`)), LIMIT_SECONDS * 1000));
  try {
    await Promise.race([run, limit]);
  } catch (error) {
    console.log(JSON.stringify({ label, kind: "error", message: String(error) }));
    process.exitCode = 1;
  }
  console.log(JSON.stringify({ label, kind: "page-errors", errors }));
  if (errors.length) process.exitCode = 1;
} finally {
  await browser.close();
  server.close();
}
