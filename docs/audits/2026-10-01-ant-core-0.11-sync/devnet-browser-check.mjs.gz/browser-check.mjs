// Adapted from docs/audits/2026-09-25-bootstrap-review-fixes/browser-check.mjs.gz
// (SDK repo). Changes: playwright import path points at the clean ant-client
// clone; wasm served to each page is hashed; and the SDK part is extended with
// a multi-record public and private upload, demo download/stream/.datamap
// flows, plus openFile() range reads and createMediaSource() byte-range fetches
// through the SDK API in the demo page context.
import { chromium } from '/private/tmp/claude-501/-Users-mick-RustroverProjects-ant-client-browser-sdk/7035cd6d-7529-4a0f-a446-aa99bfe0cf54/scratchpad/ant-client/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createCipheriv, createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const SCRATCH = '/private/tmp/claude-501/-Users-mick-RustroverProjects-ant-client-browser-sdk/7035cd6d-7529-4a0f-a446-aa99bfe0cf54/scratchpad';
const EVIDENCE = `${SCRATCH}/devnet-evidence`;
const DATA = `${SCRATCH}/data`;
const SDK_URL = '/@fs/Users/mick/RustroverProjects/ant-client-browser-sdk/dist/index.js'; // exactly what the demo's main.ts imports
const EXPECTED_WASM = '8fa35e58927fd3f5190ec43b1989313de3cc8968cac1bfa373247d4b3842fcd1';
const DEV_KEY = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80'; // public Anvil account 0
const DEV_ACCOUNT = '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266';
const MiB = 1024 * 1024;

const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const now = () => performance.now();
const secs = t => Math.round((now() - t) / 10) / 100;
const log = (o) => console.log(JSON.stringify(o));
/** Deterministic pseudo-random bytes: AES-128-CTR keystream with a fixed key/IV. */
function prng(size, label) {
  const key = createHash('sha256').update(`key:${label}`).digest().subarray(0, 16);
  const iv = createHash('sha256').update(`iv:${label}`).digest().subarray(0, 16);
  return createCipheriv('aes-128-ctr', key, iv).update(Buffer.alloc(size));
}

const info = await (await fetch('http://127.0.0.1:35000/api/info')).json();
assert.equal(info.evm.network, 'local-anvil');
assert.ok(['127.0.0.1', 'localhost'].includes(new URL(info.evm.rpc_url).hostname));
const manifest = await (await fetch('http://127.0.0.1:35000/api/browser-manifest.json')).json();
const seed = manifest.endpoints[0].multiaddr;
const rpc = async (method, params) => (await (await fetch(info.evm.rpc_url, {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
})).json()).result;
assert.equal(Number(await rpc('eth_chainId', [])), 31337, 'Anvil dev chain id');
const txCount = async () => Number(await rpc('eth_getTransactionCount', [DEV_ACCOUNT, 'latest']));

await mkdir(DATA, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/'] });
const summary = { network: info.evm.network, rpc: info.evm.rpc_url, seed };
let livePoll;
function watch(page, name) {
  const errors = [], consoleErrors = [], wasm = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()); });
  page.on('response', async response => {
    if (!new URL(response.url()).pathname.endsWith('.wasm')) return;
    try { wasm.push({ url: response.url(), sha256: sha(await response.body()) }); } catch (e) { wasm.push({ url: response.url(), error: String(e) }); }
  });
  return { name, errors, consoleErrors, wasm };
}

try {
  // ---------------------------------------------------------------- core harness
  {
    const page = await browser.newPage();
    const w = watch(page, 'core');
    await page.addInitScript(() => { window.showSaveFilePicker = undefined; });
    await page.goto('http://127.0.0.1:35173');
    await page.waitForFunction(() => typeof globalThis.runIntegration === 'function');
    const before = await txCount();
    const t = now();
    const result = await page.evaluate(options => globalThis.runIntegration(options), {
      endpoint: manifest.endpoints[0], payment: manifest.payment, rpcUrl: info.evm.rpc_url,
    });
    const seconds = secs(t);
    assert.equal(result.hello, 'hello');
    assert.equal(result.payments, 1);
    assert.equal(result.size, result.expectedSize);
    assert.equal(result.matches, true);
    assert.ok(result.records > 1);
    assert.ok(result.replicas >= 4);
    assert.deepEqual(w.errors, []);
    assert.ok(w.wasm.length >= 1 && w.wasm.every(x => x.sha256 === EXPECTED_WASM), JSON.stringify(w.wasm));
    summary.core = { ...result, seconds, anvilTxs: (await txCount()) - before, wasm: w.wasm, pageErrors: w.errors, consoleErrors: w.consoleErrors };
    log({ test: 'core production WASM paid recovery', ...summary.core });
    await page.close();
  }

  // ---------------------------------------------------------------- SDK demo
  // Each phase uses a fresh browser context whose first network action is its
  // own work. On this 7-node devnet every close-group lookup needs all seven
  // nodes, and all sessions share 127.0.0.1's per-IP admission budget; a
  // multi-record upload after another upload in the same client failed with
  // "insufficient peers" for both this candidate and the published 0.1.0 SDK
  // (see ab-large-upload.mjs results), so phases are isolated.
  const sessions = [];
  async function demoSession(name) {
    const context = await browser.newContext({ acceptDownloads: true });
    const page = await context.newPage();
    const w = watch(page, name);
    sessions.push({ name, w });
    await page.addInitScript(() => { window.showSaveFilePicker = undefined; });
    await page.goto('http://127.0.0.1:35174');
    await page.fill('#bootstrap', seed);
    const t = now();
    await page.click('#connect');
    await page.waitForFunction(() => document.querySelector('#connection').textContent.startsWith('Connected'), null, { timeout: 60_000 });
    const connectSeconds = secs(t);
    await page.fill('#payment-rpc', info.evm.rpc_url);
    // Public default Anvil account, only after checking the local-devnet guard.
    await page.fill('#wallet', DEV_KEY);
    const logText = () => page.locator('#log').textContent();
    // Live copy of the demo's #log so a stalled step is visible while it runs.
    let liveSeen = 0;
    clearInterval(livePoll);
    livePoll = setInterval(async () => {
      try {
        const text = await page.evaluate(() => document.querySelector('#log').textContent);
        if (text.length > liveSeen) {
          const fresh = text.slice(liveSeen); liveSeen = text.length;
          await writeFile(`${EVIDENCE}/sdk-demo-log.${name}.txt`, text);
          for (const line of fresh.split('\n').filter(Boolean)) console.log(`[demo ${name} ${new Date().toISOString().slice(11, 19)}] ${line}`);
        }
      } catch { /* page navigating or closed */ }
    }, 5_000);

    async function upload({ label, file, visibility }) {
      const prevAddress = await page.inputValue('#address');
      const prevLog = (await logText()).length;
      await page.selectOption('#visibility', visibility);
      await page.selectOption('#payment-mode', 'auto');
      await page.setInputFiles('#upload-input', file);
      const before = await txCount();
      const t0 = now();
      await page.click('#upload');
      // The handler disables the button synchronously and re-enables it in `finally`,
      // so a re-enabled button means the upload settled (success or failure).
      await page.waitForFunction(() => !document.querySelector('#upload').disabled, null, { timeout: 1_800_000 });
      const seconds = secs(t0);
      const tail = (await logText()).slice(prevLog);
      const ok = visibility === 'public'
        ? await page.evaluate(prev => { const v = document.querySelector('#address').value; return v.length === 64 && v !== prev; }, prevAddress)
        : await page.evaluate(() => !document.querySelector('#save-datamap').hidden);
      if (!ok) return { label, ok: false, seconds, failure: tail.split('\n').filter(l => l && !l.startsWith('[')).slice(-1)[0], anvilTxs: (await txCount()) - before };
      const stored = /Stored (\d+) records using (\w+) payment for (\d+) atto-tokens/.exec(tail);
      assert.ok(stored, `${label}: no 'Stored' line; tail: ${tail.slice(-2000)}`);
      return { label, ok: true, visibility, seconds, records: Number(stored[1]), paymentMode: stored[2], storageCostAtto: stored[3],
        anvilTxs: (await txCount()) - before, address: visibility === 'public' ? await page.inputValue('#address') : '' };
    }

    async function download(expected, label) {
      const t0 = now();
      const downloadPromise = page.waitForEvent('download', { timeout: 900_000 });
      await page.click('#download');
      const d = await downloadPromise;
      const bytes = await readFile(await d.path());
      const seconds = secs(t0);
      assert.equal(bytes.length, expected.length, `${label}: downloaded length`);
      assert.ok(bytes.equals(expected), `${label}: downloaded bytes differ`);
      return { label, bytes: bytes.length, sha256: sha(bytes), suggestedFilename: d.suggestedFilename(), seconds, matches: true };
    }

    async function stream(expected, label) {
      const prev = await page.getAttribute('#media', 'src');
      const t0 = now();
      await page.click('#stream');
      await page.waitForFunction(p => { const s = document.querySelector('#media').getAttribute('src'); return s && s !== p; }, prev, { timeout: 120_000 });
      const openSeconds = secs(t0);
      const url = await page.getAttribute('#media', 'src');
      const got = await page.evaluate(fetchRanges, { url, ranges: mediaRanges(expected.length) });
      return { label, openSeconds, url: url.replace(/\?.*$/, '?…'), ranges: checkRanges(got, expected, label) };
    }

    async function close() {
      clearInterval(livePoll);
      await writeFile(`${EVIDENCE}/sdk-demo-log.${name}.txt`, await logText());
      assert.deepEqual(w.errors, [], `${name}: page errors`);
      assert.ok(w.wasm.length >= 1 && w.wasm.every(x => x.sha256 === EXPECTED_WASM), `${name}: ${JSON.stringify(w.wasm)}`);
      await context.close();
    }
    return { page, w, connectSeconds, logText, upload, download, stream, close };
  }

  /** Upload in a fresh session; one retry in another fresh session after an "insufficient peers" failure. */
  async function uploadFresh(name, spec) {
    const attempts = [];
    for (let attempt = 1; attempt <= 2; attempt++) {
      const s = await demoSession(`${name}-${attempt}`);
      const r = await s.upload(spec);
      attempts.push({ attempt, connectSeconds: s.connectSeconds, ...r });
      if (r.ok) return { session: s, result: { ...r, connectSeconds: s.connectSeconds }, attempts };
      log({ test: `${spec.label} upload attempt failed`, attempt, failure: r.failure, seconds: r.seconds });
      await s.close();
      assert.ok(/insufficient peers/.test(r.failure ?? ''), `${spec.label}: unexpected failure ${r.failure}`);
      await new Promise(resolve => setTimeout(resolve, 10_000));
    }
    throw new Error(`${spec.label}: upload failed twice: ${JSON.stringify(attempts)}`);
  }

  // 1. Previous audit's flow: small public file through the demo UI, then download.
  {
    const s = await demoSession('small');
    const small = Buffer.from('Shared native and browser read startup regression.\n'.repeat(256));
    summary.smallUpload = await s.upload({ label: 'small public', file: { name: 'read-startup.txt', mimeType: 'text/plain', buffer: small }, visibility: 'public' });
    assert.ok(summary.smallUpload.ok, `small public upload failed: ${summary.smallUpload.failure}`);
    summary.smallUpload.connectSeconds = s.connectSeconds;
    summary.smallDownload = await s.download(small, 'small public');
    log({ test: 'SDK demo small public upload+download', upload: summary.smallUpload, download: summary.smallDownload });
    await s.close();
  }

  // 2. Multi-record public file (16 MiB + 12345 B) via the demo UI (File -> worker -> IndexedDB staging),
  //    then the demo's download and stream buttons in the same page.
  const large = prng(16 * MiB + 12345, 'public-large');
  const largePath = `${DATA}/public-large.bin`;
  await writeFile(largePath, large);
  let largeAddress;
  {
    const { session: s, result, attempts } = await uploadFresh('large', { label: 'large public', file: largePath, visibility: 'public' });
    summary.largeUpload = { ...result, size: large.length, sha256: sha(large), attempts: attempts.length, failedAttempts: attempts.filter(a => !a.ok) };
    log({ test: 'SDK demo large public upload', ...summary.largeUpload });
    largeAddress = result.address;
    summary.largeDownload = await s.download(large, 'large public');
    log({ test: 'SDK demo large public download', ...summary.largeDownload });
    summary.largeStreamDemo = await s.stream(large, 'large public demo stream');
    log({ test: 'SDK demo large public stream button', ...summary.largeStreamDemo });
    await s.close();
  }

  // 3. Private (DataMap) upload via the demo UI, save the .datamap, load it back, download and stream.
  const priv = prng(12 * MiB + 777, 'private-large');
  const privPath = `${DATA}/private-large.bin`;
  await writeFile(privPath, priv);
  let dataMap;
  {
    const { session: s, result, attempts } = await uploadFresh('private', { label: 'large private', file: privPath, visibility: 'private' });
    summary.privateUpload = { ...result, size: priv.length, sha256: sha(priv), attempts: attempts.length, failedAttempts: attempts.filter(a => !a.ok) };
    const dmPromise = s.page.waitForEvent('download', { timeout: 60_000 });
    await s.page.click('#save-datamap');
    const dmDownload = await dmPromise;
    dataMap = await readFile(await dmDownload.path());
    assert.ok(dataMap.length > 0, 'saved DataMap is empty');
    await writeFile(`${DATA}/private-large.datamap`, dataMap);
    summary.privateUpload.dataMap = { bytes: dataMap.length, sha256: sha(dataMap), suggestedFilename: dmDownload.suggestedFilename() };
    log({ test: 'SDK demo private upload + save DataMap', ...summary.privateUpload });
    await s.page.setInputFiles('#datamap-input', { name: dmDownload.suggestedFilename(), mimeType: 'application/octet-stream', buffer: dataMap });
    await s.page.waitForFunction(() => document.querySelector('#log').textContent.includes('Loaded the private DataMap'), null, { timeout: 30_000 });
    summary.privateDownload = await s.download(priv, 'private via loaded .datamap');
    log({ test: 'SDK demo private download via loaded .datamap', ...summary.privateDownload });
    summary.privateStreamDemo = await s.stream(priv, 'private demo stream');
    log({ test: 'SDK demo private stream button', ...summary.privateStreamDemo });
    await s.close();
  }

  // 4. SDK API in a fresh demo page context: openFile() ranges and createMediaSource() fetches.
  {
    const s = await demoSession('api');
    summary.apiPublic = await apiChecks(s.page, largeAddress, null, large, 'public');
    log({ test: 'SDK API public openFile/createMediaSource', ...summary.apiPublic });
    summary.apiPrivate = await apiChecks(s.page, null, dataMap, priv, 'private');
    log({ test: 'SDK API private openFile/createMediaSource', ...summary.apiPrivate });
    await s.close();
  }

  summary.sdkPages = sessions.map(({ name, w }) => ({ name, wasm: w.wasm.map(x => x.sha256), pageErrors: w.errors, consoleErrors: w.consoleErrors }));
  log({ result: 'passed', sessions: summary.sdkPages.map(p => ({ name: p.name, pageErrors: p.pageErrors.length, consoleErrors: p.consoleErrors.length, wasm: p.wasm })) });

  async function apiChecks(page, address, dataMapBytes, expected, label) {
    const size = expected.length;
    const half = Math.floor(size / 2);
    const plan = {
      // Isolated reads first (start, middle, end, truncated EOF, multi-record span),
      // then a sequential pass that continues each previous read so read-ahead engages.
      isolated: [[0, 4096], [half - 32768, 65536], [size - 65536, 65536], [size - 100, 4096], [3 * MiB + 500_000, 4 * MiB], [0, 65536]],
      sequential: Array.from({ length: Math.ceil(size / MiB) }, (_, i) => [i * MiB, MiB]),
      stream: { start: MiB + 123, end: 9 * MiB + 456, chunkSize: 512 * 1024 },
      media: mediaRanges(size),
    };
    const got = await page.evaluate(async ({ sdkUrl, seed, address, dataMap, plan, fetchRangesSrc }) => {
      const fetchRanges = eval(`(${fetchRangesSrc})`);
      const hex = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(b => b.toString(16).padStart(2, '0')).join('');
      const { AutonomiClient } = await import(sdkUrl);
      const target = address ?? { dataMap: new Uint8Array(dataMap), name: 'api-private.bin' };
      const t0 = performance.now();
      const client = await AutonomiClient.connect(seed);
      const out = { connectMs: Math.round(performance.now() - t0) };
      try {
        let t = performance.now();
        const reader = await client.openFile(target);
        out.openMs = Math.round(performance.now() - t);
        out.reader = { size: reader.size, name: reader.name, address: reader.address, contentType: reader.contentType };
        try {
          const run = async ranges => {
            const rows = [];
            for (const [start, length] of ranges) {
              const s = performance.now();
              const bytes = await reader.read(start, length);
              rows.push({ start, length, got: bytes.byteLength, sha256: await hex(bytes), ms: Math.round(performance.now() - s) });
            }
            return rows;
          };
          out.isolated = await run(plan.isolated);
          t = performance.now();
          out.sequential = await run(plan.sequential);
          out.sequentialMs = Math.round(performance.now() - t);
          t = performance.now();
          const parts = [];
          const streamReader = reader.stream(plan.stream).getReader();
          for (;;) { const { done, value } = await streamReader.read(); if (done) break; parts.push(value); }
          const joined = new Uint8Array(parts.reduce((n, p) => n + p.byteLength, 0));
          let o = 0; for (const p of parts) { joined.set(p, o); o += p.byteLength; }
          out.stream = { ...plan.stream, chunks: parts.length, got: joined.byteLength, sha256: await hex(joined), ms: Math.round(performance.now() - t) };
        } finally { reader.close(); }
        t = performance.now();
        const source = await client.createMediaSource(target);
        out.mediaOpenMs = Math.round(performance.now() - t);
        out.mediaFile = source.file;
        try {
          out.media = await fetchRanges({ url: source.url, ranges: plan.media });
        } finally { source.close(); }
      } finally { client.close(); }
      return out;
    }, { sdkUrl: SDK_URL, seed, address, dataMap: dataMapBytes ? [...dataMapBytes] : null, plan, fetchRangesSrc: fetchRanges.toString() });

    assert.equal(got.reader.size, size, `${label}: reader.size`);
    if (address) assert.equal(got.reader.address, address, `${label}: reader.address`);
    else assert.equal(got.reader.address, '', `${label}: private reader address must be empty`);
    const check = rows => rows.map(r => {
      const want = expected.subarray(r.start, Math.min(size, r.start + r.length));
      assert.equal(r.got, want.length, `${label}: read ${r.start}+${r.length} length`);
      assert.equal(r.sha256, sha(want), `${label}: read ${r.start}+${r.length} bytes differ`);
      return { start: r.start, length: r.length, got: r.got, ms: r.ms, matches: true };
    });
    const isolated = check(got.isolated);
    const sequential = check(got.sequential);
    assert.equal(sequential.reduce((n, r) => n + r.got, 0), size, `${label}: sequential total`);
    const wantStream = expected.subarray(plan.stream.start, plan.stream.end);
    assert.equal(got.stream.got, wantStream.length); assert.equal(got.stream.sha256, sha(wantStream), `${label}: stream bytes differ`);
    assert.equal(got.mediaFile.size, size);
    return { label, connectMs: got.connectMs, openMs: got.openMs, reader: got.reader, isolated,
      sequential: { reads: sequential.length, bytes: size, totalMs: got.sequentialMs, perReadMs: sequential.map(r => r.ms) },
      stream: { start: got.stream.start, end: got.stream.end, chunkSize: got.stream.chunkSize, chunks: got.stream.chunks, bytes: got.stream.got, ms: got.stream.ms, matches: true },
      mediaOpenMs: got.mediaOpenMs, mediaFile: got.mediaFile, media: checkRanges(got.media, expected, `${label} media`) };
  }
} catch (error) {
  summary.error = String(error?.stack ?? error);
  throw error;
} finally {
  clearInterval(livePoll);
  await writeFile(`${EVIDENCE}/summary.json`, JSON.stringify(summary, null, 2));
  await browser.close();
}

function mediaRanges(size) {
  const mid = Math.floor(size / 2);
  return [`bytes=0-65535`, `bytes=${mid}-${mid + 65535}`, `bytes=-65536`, `bytes=${5 * MiB + 7}-${8 * MiB + 6}`, `bytes=${size - 1000}-`];
}

// Runs in the page: fetch byte ranges through the media service worker.
async function fetchRanges({ url, ranges }) {
  const hex = async bytes => [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(b => b.toString(16).padStart(2, '0')).join('');
  const rows = [];
  for (const range of ranges) {
    const s = performance.now();
    const response = await fetch(url, { headers: { Range: range } });
    const body = new Uint8Array(await response.arrayBuffer());
    rows.push({ range, status: response.status, contentRange: response.headers.get('content-range'),
      contentLength: response.headers.get('content-length'), got: body.byteLength, sha256: await hex(body), ms: Math.round(performance.now() - s),
      controlled: !!navigator.serviceWorker.controller });
  }
  return rows;
}

function checkRanges(rows, expected, label) {
  const size = expected.length;
  return rows.map(r => {
    const m = /^bytes=(\d*)-(\d*)$/.exec(r.range);
    let start, end;
    if (!m[1]) { start = Math.max(0, size - Number(m[2])); end = size - 1; }
    else { start = Number(m[1]); end = m[2] ? Math.min(Number(m[2]), size - 1) : size - 1; }
    const want = expected.subarray(start, end + 1);
    assert.equal(r.status, 206, `${label} ${r.range}: status`);
    assert.equal(r.contentRange, `bytes ${start}-${end}/${size}`, `${label} ${r.range}: content-range`);
    assert.equal(r.got, want.length, `${label} ${r.range}: length`);
    assert.equal(r.sha256, sha(want), `${label} ${r.range}: bytes differ`);
    assert.ok(r.controlled, `${label}: page not controlled by service worker`);
    return { range: r.range, status: r.status, contentRange: r.contentRange, bytes: r.got, ms: r.ms, matches: true };
  });
}
