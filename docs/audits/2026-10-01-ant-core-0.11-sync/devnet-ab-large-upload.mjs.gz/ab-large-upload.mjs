// A/B: the same scratch all-in-one demo page served against the candidate SDK dist
// (35175) and the published @withautonomi/ant-browser-sdk@0.1.0 dist (35176), on the
// same devnet. Each trial uploads fresh deterministic content through the demo UI.
// Usage: node ab-large-upload.mjs <sizeBytes> <trialsPerVariant> [variants]
import { chromium } from '/private/tmp/claude-501/-Users-mick-RustroverProjects-ant-client-browser-sdk/7035cd6d-7529-4a0f-a446-aa99bfe0cf54/scratchpad/ant-client/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { writeFile, mkdir } from 'node:fs/promises';
import { createCipheriv, createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const SCRATCH = '/private/tmp/claude-501/-Users-mick-RustroverProjects-ant-client-browser-sdk/7035cd6d-7529-4a0f-a446-aa99bfe0cf54/scratchpad';
const DATA = `${SCRATCH}/data`;
const DEV_KEY = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80'; // public Anvil account 0
const PORTS = { candidate: 35175, baseline: 35176 };
const size = Number(process.argv[2] ?? 16 * 1024 * 1024 + 12345);
const trials = Number(process.argv[3] ?? 3);
const variants = (process.argv[4] ?? 'baseline,candidate').split(',');
const tag = process.argv[5] ?? `${Date.now()}`;
// warm=1: first upload a small 4-record file in the same page/client, as the main probe does.
const warm = process.argv[6] === '1';
const delayMs = Number(process.argv[7] ?? 0); // pause between the warm-up and the large upload
const sha = b => createHash('sha256').update(b).digest('hex');
function prng(n, label) {
  const key = createHash('sha256').update(`key:${label}`).digest().subarray(0, 16);
  const iv = createHash('sha256').update(`iv:${label}`).digest().subarray(0, 16);
  return createCipheriv('aes-128-ctr', key, iv).update(Buffer.alloc(n));
}

const info = await (await fetch('http://127.0.0.1:35000/api/info')).json();
assert.equal(info.evm.network, 'local-anvil');
assert.ok(['127.0.0.1', 'localhost'].includes(new URL(info.evm.rpc_url).hostname));
const manifest = await (await fetch('http://127.0.0.1:35000/api/browser-manifest.json')).json();
await mkdir(DATA, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/'] });
try {
  for (let trial = 0; trial < trials; trial++) {
    for (const variant of variants) {
      const context = await browser.newContext();
      const page = await context.newPage();
      const errors = [], wasm = [];
      page.on('pageerror', e => errors.push(e.message));
      page.on('response', async r => { if (new URL(r.url()).pathname.endsWith('.wasm')) { try { wasm.push(sha(await r.body())); } catch {} } });
      await page.goto(`http://127.0.0.1:${PORTS[variant]}`);
      await page.fill('#bootstrap', manifest.endpoints[0].multiaddr);
      await page.click('#connect');
      await page.waitForFunction(() => document.querySelector('#connection').textContent.startsWith('Connected'), null, { timeout: 60_000 });
      await page.fill('#payment-rpc', info.evm.rpc_url);
      await page.fill('#wallet', DEV_KEY);
      let warmResult;
      if (warm) {
        const small = prng(13056, `warm-${tag}-${variant}-${trial}`);
        await page.setInputFiles('#upload-input', { name: 'warm.bin', mimeType: 'application/octet-stream', buffer: small });
        const b0 = (await page.locator('#log').textContent()).length;
        const tw = performance.now();
        await page.click('#upload');
        await page.waitForFunction(() => !document.querySelector('#upload').disabled, null, { timeout: 600_000 });
        const wt = (await page.locator('#log').textContent()).slice(b0);
        warmResult = { ok: (await page.inputValue('#address')).length === 64, seconds: Math.round(performance.now() - tw) / 1000,
          stored: /Stored (\d+) records/.exec(wt)?.[1], failure: wt.split('\n').find(l => /failed|insufficient/i.test(l) && !l.startsWith('[')) };
        await page.fill('#address', '');
        await page.waitForTimeout(delayMs);
      }
      const content = prng(size, `ab-${tag}-${variant}-${trial}`);
      const path = `${DATA}/ab-${variant}-${trial}.bin`;
      await writeFile(path, content);
      await page.selectOption('#visibility', 'public');
      await page.selectOption('#payment-mode', 'auto');
      await page.setInputFiles('#upload-input', path);
      const before = (await page.locator('#log').textContent()).length;
      const t0 = performance.now();
      await page.click('#upload');
      await page.waitForFunction(() => !document.querySelector('#upload').disabled, null, { timeout: 1_800_000 });
      const seconds = Math.round(performance.now() - t0) / 1000;
      const tail = (await page.locator('#log').textContent()).slice(before);
      const address = await page.inputValue('#address');
      const stored = /Stored (\d+) records using (\w+) payment/.exec(tail);
      const lines = tail.split('\n').filter(Boolean);
      const failure = lines.find(l => /failed|error|insufficient/i.test(l) && !l.startsWith('['));
      console.log(JSON.stringify({ trial, variant, warm: warmResult, delayMs, size, sha256: sha(content).slice(0, 16), ok: address.length === 64 && !!stored,
        seconds, records: stored ? Number(stored[1]) : undefined, paymentMode: stored?.[2], address: address || undefined,
        failure, wasm, pageErrors: errors }));
      await writeFile(`${SCRATCH}/devnet-evidence/ab-${tag}-${variant}-${trial}.log.txt`, await page.locator('#log').textContent());
      await context.close();
    }
  }
} finally { await browser.close(); }
