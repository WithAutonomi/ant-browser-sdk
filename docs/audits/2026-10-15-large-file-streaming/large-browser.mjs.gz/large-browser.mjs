import { chromium } from '/Users/mick/RustroverProjects/ant-client-wasm-large-files/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { readFile, writeFile, mkdtemp, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const sdkRoot='/Users/mick/RustroverProjects/ant-browser-sdk-pr6-20261015';
const fixture=JSON.parse(await readFile('/Users/mick/RustroverProjects/ant-client-sdk-sync-20261015/ant-core/wasm-tests/fixtures/large-file.json','utf8'));
const uploaded=JSON.parse(await readFile('/private/tmp/sdk-20261015-large/upload.json','utf8'));
assert.equal(uploaded.address,fixture.address);
const manifest=await (await fetch('http://127.0.0.1:39870/api/browser-manifest.json')).json();
const source=JSON.parse(await readFile(`${sdkRoot}/src/wasm/source.json`,'utf8'));
const dataMap=[...Buffer.from(fixture.records.find(r=>r.address===fixture.address).content,'hex')];
const profile=await mkdtemp('/private/tmp/sdk-20261015-chromium-');
const context=await chromium.launchPersistentContext(profile,{headless:true,args:['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/']});
const page=await context.newPage();
const errors=[],hashes=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
page.on('response',async r=>{if(new URL(r.url()).pathname.endsWith('.wasm'))hashes.push(createHash('sha256').update(await r.body()).digest('hex'));});
try {
  await page.goto('http://127.0.0.1:39871', {waitUntil:'networkidle'});
  const result=await page.evaluate(async ({sdkUrl,seed,payment,file,dataMap})=>{
    const sdk=await import(sdkUrl);
    const client=await sdk.AutonomiClient.connect(seed,{expectedPaymentNetwork:{chainId:payment.chain_id,paymentTokenAddress:payment.payment_token_address,paymentVaultAddress:payment.payment_vault_address}});
    const ensure=(condition,message)=>{if(!condition)throw Error(message);};
    const matches=b=>b.every(x=>x===file.byte);
    const boundary=2**32, probe=16;
    const root=await navigator.storage.getDirectory();
    let reader,media;
    const results={size:file.size,ranges:[],budgets:[],cancellation:[]};
    try {
      for(const [visibility,target] of [['public',file.address],['private',{dataMap:Uint8Array.from(dataMap)}]]){
        reader=await client.openFile(target);
        ensure(reader.size===file.size,`${visibility} size`);
        for(const start of [0,1_000_000_001,boundary-8,file.size-probe]){
          const bytes=await reader.read(start,probe);
          ensure(bytes.length===probe&&matches(bytes),`${visibility} seek ${start}`);
          results.ranges.push({visibility,start,bytes:bytes.length});
        }
        let failure;
        try {await client.download(target,{maxMemoryBytes:64*1024*1024});}catch(e){failure=e;}
        ensure(failure?.code==='DOWNLOAD_FAILED'&&failure.message.includes('pipeTo'),`${visibility} memory budget`);
        results.budgets.push({visibility,code:failure.code,message:failure.message});
        if(visibility==='public'){
          const handle=await root.getFileHandle('large.bin',{create:true});
          let lastProgress=0,progressCalls=0;
          const started=performance.now();
          const piped=await reader.pipeTo(await handle.createWritable(),{onProgress:(written,total)=>{
            ensure(total===file.size&&written>=lastProgress,'progress');lastProgress=written;progressCalls++;
          }});
          const seconds=(performance.now()-started)/1000;
          const stored=await handle.getFile();
          ensure(piped.bytesWritten===file.size&&piped.hash===file.hash&&stored.size===file.size,'full output size/hash');
          for(const start of [boundary-8,file.size-probe])ensure(matches(new Uint8Array(await stored.slice(start,start+probe).arrayBuffer())),'stored bytes');
          ensure(lastProgress===file.size,'final progress');
          results.disk={...piped,storedSize:stored.size,seconds,progressCalls,lastProgress};
          await root.removeEntry('large.bin');
        }else{
          const handle=await root.getFileHandle('private-range.bin',{create:true});
          const piped=await reader.pipeTo(await handle.createWritable(),{start:boundary-8,end:boundary+8});
          const bytes=new Uint8Array(await (await handle.getFile()).arrayBuffer());
          ensure(piped.bytesWritten===probe&&bytes.length===probe&&matches(bytes),'private pipe');
          results.privatePipe=piped;await root.removeEntry('private-range.bin');
        }
        reader.close();reader=undefined;
      }
      for(const method of ['signal','close']){
        reader=await client.openFile(file.address);
        const controller=new AbortController();
        let release,entered,aborted;
        const started=new Promise(resolve=>{entered=resolve;});
        const destination=new WritableStream({write(){entered();return new Promise(resolve=>{release=resolve;});},abort(reason){aborted=reason;}});
        const pipe=reader.pipeTo(destination,{start:0,end:8*1024*1024,signal:controller.signal}).then(()=>({ok:true}),error=>({error}));
        await started;
        if(method==='signal')controller.abort('cancel stalled write');else reader.close();
        const settled=await Promise.race([pipe,new Promise((_,reject)=>setTimeout(()=>reject(Error('cancellation timeout')),5000))]);
        ensure(settled.error!==undefined&&!destination.locked,'cancel settles and releases lock');
        if(method==='signal')ensure(settled.error==='cancel stalled write','abort reason preserved');
        else ensure(settled.error.name==='AbortError','reader-close abort');
        release();await new Promise(resolve=>setTimeout(resolve,50));
        ensure(aborted!==undefined,'destination abort');
        results.cancellation.push({method,unlocked:!destination.locked,aborted:true});
        reader.close();reader=undefined;
      }
      media=await client.createMediaSource(file.address,{primePlayback:true});
      const response=await fetch(media.url,{headers:{Range:`bytes=${boundary-8}-${boundary+7}`}});
      const bytes=new Uint8Array(await response.arrayBuffer());
      ensure(response.status===206&&bytes.length===probe&&matches(bytes),'large media range');
      ensure(response.headers.get('content-range')===`bytes ${boundary-8}-${boundary+7}/${file.size}`,'content-range');
      results.media={status:response.status,contentRange:response.headers.get('content-range'),bytes:bytes.length};
      media.close();media=undefined;
      return results;
    }finally{reader?.close();media?.close();client.close();}
  },{sdkUrl:`/@fs${sdkRoot}/dist/index.js`,seed:manifest.endpoints[0].multiaddr,payment:manifest.payment,file:{address:fixture.address,size:fixture.size,byte:fixture.byte,hash:fixture.hash},dataMap});
  assert.deepEqual(errors,[]);assert.ok(hashes.length>0&&hashes.every(x=>x===source.wasmSha256));
  const summary={browser:context.browser()?.version(),sdkBase:'29ab1758e1188fc445b82465949dcc655345935b',sdkRevision:'456dbb7b6b6ccbcce0603bbae2fd7b1664b68975',wasm:source.revision,node:'26129a2611cac08f9f53a557f91fb8806b40a1cc',wasmSha256:source.wasmSha256,result,errors,hashes};
  await writeFile('/private/tmp/sdk-20261015-large-summary.json',JSON.stringify(summary,null,2)+'\n');
  console.log(JSON.stringify(summary,null,2));
}finally{await context.close();await rm(profile,{recursive:true,force:true});}
