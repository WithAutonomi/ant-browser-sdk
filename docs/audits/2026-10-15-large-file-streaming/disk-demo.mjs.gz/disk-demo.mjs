import { chromium } from '/Users/mick/RustroverProjects/ant-client-wasm-large-files/ant-core/browser-tests/node_modules/playwright/index.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const manifest=await (await fetch('http://127.0.0.1:39870/api/browser-manifest.json')).json();
const small=JSON.parse(await readFile('/private/tmp/sdk-20261015-browser-summary.json','utf8')).phases[0];
const browser=await chromium.launch({headless:true,args:['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/']});
try{
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{window.showSaveFilePicker=async()=>{
  const root=await navigator.storage.getDirectory();return root.getFileHandle('demo-disk.bin',{create:true});
 };});
 await page.goto('http://127.0.0.1:39871');
 await page.locator('#bootstrap').fill(manifest.endpoints[0].multiaddr);await page.locator('#connect').click();
 await page.waitForFunction(()=>document.querySelector('#connection').value.startsWith('Connected'),null,{timeout:60000});
 await page.locator('#address').fill(small.address);await page.locator('#download-to-disk').click();
 await page.waitForFunction(()=>document.querySelector('#log').textContent.includes('bytes to demo-disk.bin; BLAKE3'),null,{timeout:60000});
 const result=await page.evaluate(async()=>{
  const root=await navigator.storage.getDirectory();const file=await(await root.getFileHandle('demo-disk.bin')).getFile();
  const bytes=new Uint8Array(await file.arrayBuffer());
  const matched=bytes.every((x,i)=>x===(i*37+11)%256);
  await root.removeEntry('demo-disk.bin');
  return {size:bytes.length,matched,cancelDisabled:document.querySelector('#cancel-download').disabled,log:document.querySelector('#log').textContent.split('\n').at(-1)};
 });
 assert.equal(result.size,13056);assert.ok(result.matched&&result.cancelDisabled);assert.deepEqual(errors,[]);
 await writeFile('/private/tmp/sdk-20261015-disk-demo-summary.json',JSON.stringify({browser:browser.version(),result,errors},null,2)+'\n');
 console.log(JSON.stringify(result));
}finally{await browser.close();}
