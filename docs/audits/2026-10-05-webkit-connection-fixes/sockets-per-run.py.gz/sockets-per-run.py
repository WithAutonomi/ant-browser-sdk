"""Attribute WebKit's NetworkRTCProvider log lines to harness runs by wall-clock time.

usage: python3 sockets-per-run.py <runs.jsonl> <webkit-log.txt>
The log is `log show --style compact` output filtered to NetworkRTCProvider lines.
"""
import json
import re
import sys
from datetime import datetime

runs_path, log_path = sys.argv[1], sys.argv[2]
TOTAL = re.compile(r"total socket number is (\d+)")
STAMP = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})")

events = []
for line in open(log_path):
    match = STAMP.match(line)
    if not match:
        continue
    at = datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S.%f").timestamp() * 1000
    if "too many sockets" in line:
        events.append((at, "closed", None))
    elif (total := TOTAL.search(line)):
        events.append((at, "total", int(total.group(1))))

print(f"{'run':>3} {'variant':8} {'text_s':>7} {'video_s':>8} {'peak sockets':>12} {'forced closes':>13}")
for line in open(runs_path):
    run = json.loads(line)
    if "startedAt" not in run:
        continue
    window = [e for e in events if run["startedAt"] <= e[0] <= run["endedAt"]]
    peak = max((value for _, kind, value in window if kind == "total"), default=0)
    closes = sum(1 for _, kind, _ in window if kind == "closed")
    seconds = {f["name"][:4]: f["seconds"] for f in run.get("files", [])}
    print(f"{run['run']:>3} {run['variant']:8} {seconds.get('Welc', 0):7.1f} {seconds.get('Mand', 0):8.1f} {peak:12d} {closes:13d}")
