// Which gate between gathering starts keeps WebKit at two real sockets per
// connection, and what does it cost? Phases are timestamped for `log show`.
// usage: node gate-strategies.mjs <browser>
import * as playwright from "playwright";
import { createServer } from "node:http";

const browserName = process.argv[2] ?? "webkit";
const server = createServer((_, res) => res.writeHead(200, { "Content-Type": "text/html" }).end("<!doctype html><title>gates</title>"));
await new Promise(done => server.listen(0, "127.0.0.1", done));
const browser = await playwright[browserName].launch({ headless: true });
const page = await browser.newPage();
await page.goto(`http://127.0.0.1:${server.address().port}/`);
const phases = await page.evaluate(async () => {
  const sleep = ms => new Promise(done => setTimeout(done, ms));
  const complete = pc => pc.iceGatheringState === "complete" ? Promise.resolve()
    : new Promise(done => { pc.addEventListener("icegatheringstatechange", () => pc.iceGatheringState === "complete" && done()); setTimeout(done, 5000); });
  const firstCandidate = pc => new Promise(done => {
    pc.addEventListener("icecandidate", event => event.candidate && done());
    pc.addEventListener("icegatheringstatechange", () => pc.iceGatheringState === "complete" && done());
    setTimeout(done, 5000);
  });
  const N = 12;
  const out = [];
  // All N dials start together, as a lookup round does; the gate decides when each may set its local description.
  const phase = async (name, gate) => {
    const begin = Date.now();
    let previous = Promise.resolve();
    const startedAt = [];
    const pcs = await Promise.all(Array.from({ length: N }, async (_, i) => {
      const pc = new RTCPeerConnection();
      pc.createDataChannel("x");
      const offer = await pc.createOffer();
      const turn = previous;
      let release;
      previous = new Promise(done => { release = done; });
      await turn;
      startedAt.push(Date.now() - begin);
      await pc.setLocalDescription(offer);
      gate(pc).then(release);
      return pc;
    }));
    await Promise.all(pcs.map(complete));
    out.push({ name, begin, end: Date.now(), lastStart: Math.max(...startedAt) });
    pcs.forEach(pc => pc.close());
    await sleep(3000);
  };
  await phase("no gate", () => Promise.resolve());
  await phase("spaced 50ms", () => sleep(50));
  await phase("spaced 100ms", () => sleep(100));
  await phase("spaced 150ms", () => sleep(150));
  await phase("until first candidate", firstCandidate);
  await phase("until gathering complete", complete);
  return out;
});
console.log(JSON.stringify({ browser: browserName, version: browser.version(), phases }));
await browser.close();
server.close();
