// For several creation patterns, count both the UDP candidates in each offer and the
// sockets WebKit's NetworkRTCProvider logs, by timestamping each phase.
// usage: node sockets-vs-candidates.mjs   (then match phases against `log show`)
import * as playwright from "playwright";
import { createServer } from "node:http";

const server = createServer((_, res) => res.writeHead(200, { "Content-Type": "text/html" }).end("<!doctype html><title>sockets</title>"));
await new Promise(done => server.listen(0, "127.0.0.1", done));
const browser = await playwright.webkit.launch({ headless: true });
const page = await browser.newPage();
await page.goto(`http://127.0.0.1:${server.address().port}/`);
const phases = await page.evaluate(async () => {
  const sleep = ms => new Promise(done => setTimeout(done, ms));
  const candidates = pc => pc.localDescription.sdp.split(/\r?\n/).filter(line => line.startsWith("a=candidate") && line.includes(" udp ")).length;
  const complete = pc => pc.iceGatheringState === "complete" ? Promise.resolve()
    : new Promise(done => { pc.addEventListener("icegatheringstatechange", () => pc.iceGatheringState === "complete" && done()); setTimeout(done, 5000); });
  const out = [];
  const phase = async (name, n, start) => {
    const begin = Date.now();
    const pcs = await start(n);
    await Promise.all(pcs.map(complete));
    const end = Date.now();
    out.push({ name, n, begin, end, candidates: pcs.map(candidates).reduce((a, b) => a + b, 0) });
    pcs.forEach(pc => pc.close());
    await sleep(3000);
  };
  const offer = pc => { pc.createDataChannel("x"); return pc.createOffer(); };
  const N = 12;
  // Everything at once.
  await phase("together", N, async n => {
    const pcs = Array.from({ length: n }, () => new RTCPeerConnection());
    const offers = await Promise.all(pcs.map(offer));
    await Promise.all(pcs.map((pc, i) => pc.setLocalDescription(offers[i])));
    return pcs;
  });
  // Constructed together, setLocalDescription 10 ms apart (what the transport gate does).
  await phase("gather spaced 10ms", N, async n => {
    const pcs = Array.from({ length: n }, () => new RTCPeerConnection());
    const offers = await Promise.all(pcs.map(offer));
    for (const [i, pc] of pcs.entries()) { pc.setLocalDescription(offers[i]); await sleep(10); }
    return pcs;
  });
  // Each constructed, offered and started in turn, 10 ms apart.
  await phase("each in turn 10ms", N, async n => {
    const pcs = [];
    for (let i = 0; i < n; i++) { const pc = new RTCPeerConnection(); await pc.setLocalDescription(await offer(pc)); pcs.push(pc); await sleep(10); }
    return pcs;
  });
  // Each waits for the previous gathering to complete.
  await phase("serialized", N, async n => {
    const pcs = [];
    for (let i = 0; i < n; i++) { const pc = new RTCPeerConnection(); await pc.setLocalDescription(await offer(pc)); await complete(pc); pcs.push(pc); }
    return pcs;
  });
  // One connection alone.
  await phase("single", 1, async n => {
    const pc = new RTCPeerConnection(); await pc.setLocalDescription(await offer(pc)); return [pc];
  });
  return out;
});
console.log(JSON.stringify(phases));
await browser.close();
server.close();
