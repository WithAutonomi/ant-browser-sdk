// Network-free reproduction of the WebKit RTC socket cap.
// 1. Host candidates (= UDP sockets) per RTCPeerConnection when N are created at once vs one after another.
// 2. A connected loopback pair A<->B exchanging a DataChannel message every 500 ms, then a burst of K idle
//    RTCPeerConnections is created; does A<->B survive?
// usage: node socket-cap-repro.mjs <browser> [burst=14] [watchSeconds=30]
import { createServer } from "node:http";
import { networkInterfaces } from "node:os";
import { writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import * as playwright from "playwright";

const here = fileURLToPath(new URL(".", import.meta.url));
const [browserName = "webkit", burstArg = "14", watchArg = "30"] = process.argv.slice(2);
const lanIp = Object.values(networkInterfaces()).flat().find(a => a.family === "IPv4" && !a.internal)?.address;
const server = createServer((_, res) => res.writeHead(200, { "Content-Type": "text/html" }).end("<!doctype html><title>socket cap</title>"));
await new Promise(done => server.listen(0, "127.0.0.1", done));
const browser = await playwright[browserName].launch({ headless: true });
const page = await browser.newPage();
await page.goto(`http://127.0.0.1:${server.address().port}/`);
const result = { browser: browserName, version: browser.version(), lanIp };

result.gathering = await page.evaluate(async () => {
  const gather = async pc => {
    pc.createDataChannel("probe");
    await pc.setLocalDescription(await pc.createOffer());
    if (pc.iceGatheringState !== "complete") await new Promise(done => { pc.addEventListener("icegatheringstatechange", () => pc.iceGatheringState === "complete" && done()); setTimeout(done, 5000); });
    return pc.localDescription.sdp.split(/\r?\n/).filter(line => line.startsWith("a=candidate") && line.includes(" udp ")).length;
  };
  const out = {};
  for (const n of [1, 2, 4, 8]) {
    const together = Array.from({ length: n }, () => new RTCPeerConnection());
    out[`together-${n}`] = await Promise.all(together.map(gather));
    together.forEach(pc => pc.close());
    await new Promise(done => setTimeout(done, 300));
    const oneByOne = [];
    for (let i = 0; i < n; i++) { const pc = new RTCPeerConnection(); oneByOne.push(await gather(pc)); together.push(pc); }
    out[`sequential-${n}`] = oneByOne;
    together.forEach(pc => pc.close());
    await new Promise(done => setTimeout(done, 300));
  }
  return out;
});
console.log(JSON.stringify(result.gathering));

result.loopback = await page.evaluate(async ({ lanIp, burst, watchSeconds }) => {
  const t0 = performance.now(); const at = () => Math.round(performance.now() - t0) / 1000;
  const events = [];
  // WebKit hides host IPs behind mDNS names; point both sides at the LAN address instead.
  const fix = candidate => candidate && candidate.candidate ? new RTCIceCandidate({ ...candidate.toJSON(), candidate: candidate.candidate.replace(/\S+\.local/, lanIp) }) : candidate;
  const a = new RTCPeerConnection(); const b = new RTCPeerConnection();
  for (const [name, pc] of [["A", a], ["B", b]]) pc.addEventListener("connectionstatechange", () => events.push([at(), name, pc.connectionState]));
  a.addEventListener("icecandidate", event => event.candidate && b.addIceCandidate(fix(event.candidate)).catch(() => {}));
  b.addEventListener("icecandidate", event => event.candidate && a.addIceCandidate(fix(event.candidate)).catch(() => {}));
  const channel = a.createDataChannel("loop");
  let received = 0, lastReceived = null;
  b.addEventListener("datachannel", event => event.channel.addEventListener("message", () => { received++; lastReceived = at(); }));
  await a.setLocalDescription(await a.createOffer()); await b.setRemoteDescription(a.localDescription);
  await b.setLocalDescription(await b.createAnswer()); await a.setRemoteDescription(b.localDescription);
  await new Promise((done, fail) => { channel.addEventListener("open", done); setTimeout(() => fail(new Error("loopback channel never opened")), 15000); });
  events.push([at(), "channel", "open"]);
  let sent = 0;
  const ticker = setInterval(() => { if (channel.readyState === "open") { channel.send("x"); sent++; } }, 500);
  await new Promise(done => setTimeout(done, 3000));
  const receivedBeforeBurst = received;
  events.push([at(), "burst", burst]);
  const extra = Array.from({ length: burst }, () => new RTCPeerConnection());
  const candidates = await Promise.all(extra.map(async pc => {
    pc.createDataChannel("idle");
    await pc.setLocalDescription(await pc.createOffer());
    await new Promise(done => { pc.addEventListener("icegatheringstatechange", () => pc.iceGatheringState === "complete" && done()); setTimeout(done, 5000); });
    return pc.localDescription.sdp.split(/\r?\n/).filter(line => line.startsWith("a=candidate") && line.includes(" udp ")).length;
  }));
  events.push([at(), "burst-gathered", candidates.reduce((x, y) => x + y, 0)]);
  const samples = [];
  const watchStart = performance.now();
  while (performance.now() - watchStart < watchSeconds * 1000) {
    await new Promise(done => setTimeout(done, 1000));
    const stats = await a.getStats(); let pair;
    stats.forEach(s => { if (s.type === "candidate-pair" && s.nominated && s.state === "succeeded") pair = s; });
    samples.push([at(), a.connectionState, b.connectionState, sent, received, pair?.requestsSent, pair?.responsesReceived]);
  }
  clearInterval(ticker);
  const summary = { events, receivedBeforeBurst, sent, received, lastReceived, burstCandidates: candidates, samples };
  [a, b, ...extra].forEach(pc => pc.close());
  return summary;
}, { lanIp, burst: Number(burstArg), watchSeconds: Number(watchArg) }).catch(error => ({ error: String(error) }));
console.log(JSON.stringify({ ...result.loopback, samples: undefined }));
console.log("last samples", JSON.stringify(result.loopback.samples?.slice(-3)));
await browser.close();
server.close();
mkdirSync(join(here, "runs"), { recursive: true });
writeFileSync(join(here, "runs", `socket-cap-${browserName}-${burstArg}.json`), JSON.stringify(result, null, 1));
