// Matched try-page downloads on the live network, one fresh browser per run, with
// every RTCPeerConnection and DataChannel event recorded.
//
// usage: node harness.mjs <browser> <rounds> <label> <variant>[,<variant>...] [--only-video]
// Variants are directories under ./variants holding ant_core.js and ant_core_bg.wasm.
// Each round runs every variant once; the variant that goes first rotates each round.
import { createServer } from "node:http";
import { createHash } from "node:crypto";
import { appendFileSync, mkdirSync, readFileSync } from "node:fs";
import { extname, join, normalize, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import * as playwright from "playwright";

const here = fileURLToPath(new URL(".", import.meta.url));
const tryRoot = resolve(here, "../try");
const [browserName = "webkit", roundsArg = "1", label = "run", variantsArg = "old,new"] = process.argv.slice(2);
const onlyVideo = process.argv.includes("--only-video");
const variants = variantsArg.split(",");
const RUN_LIMIT_MS = 600_000;
const out = join(here, "runs", `${label}.jsonl`);
mkdirSync(join(here, "runs"), { recursive: true });

const featured = JSON.parse(readFileSync(join(tryRoot, "content/featured.live.json"), "utf8"));
const byName = name => featured.files.find(file => file.name === name);
const files = [...(onlyVideo ? [] : [byName("Welcome.md")]), byName("Mandelbrot zoom.mp4")];

const types = { ".js": "text/javascript", ".mjs": "text/javascript", ".wasm": "application/wasm", ".html": "text/html", ".css": "text/css",
  ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".woff2": "font/woff2" };
const wasmHash = {};
for (const variant of variants) {
  wasmHash[variant] = createHash("sha256").update(readFileSync(join(here, "variants", variant, "ant_core_bg.wasm"))).digest("hex");
}
const server = createServer((req, res) => {
  const url = new URL(req.url, "http://localhost");
  const [, variant, ...rest] = url.pathname.split("/");
  if (!variants.includes(variant)) { res.writeHead(404).end(); return; }
  const path = rest.join("/") || "index.html";
  let file;
  if (path === "pkg/ant_core.js" || path === "pkg/ant_core_bg.wasm") file = join(here, "variants", variant, path.slice(4));
  else if (path === "network.json") file = join(tryRoot, "content/network.live.json");
  else if (path === "featured.json") file = join(tryRoot, "content/featured.live.json");
  else file = normalize(join(tryRoot, "web", path));
  if (!file.startsWith(tryRoot) && !file.startsWith(here)) { res.writeHead(403).end(); return; }
  try {
    const body = readFileSync(file);
    res.writeHead(200, { "Content-Type": types[extname(file)] ?? "application/octet-stream", "Cache-Control": "no-store" });
    res.end(body);
  } catch { res.writeHead(404).end(); }
});
await new Promise(done => server.listen(0, "127.0.0.1", done));
const port = server.address().port;

// Installed before the page's own scripts, so try's trace wrapper extends this one.
const probe = () => {
  const t0 = performance.now();
  const now = () => Math.round(performance.now() - t0);
  const P = { pcs: [], channels: [] };
  window.__probe = P;
  const Native = window.RTCPeerConnection;
  if (typeof Native !== "function") return;
  class ProbePeerConnection extends Native {
    constructor(...args) {
      super(...args);
      const pc = { id: P.pcs.length + 1, created: now(), states: [], endpoint: null };
      P.pcs.push(pc);
      this.__probe = pc;
      this.addEventListener("connectionstatechange", () => pc.states.push([now(), this.connectionState]));
      this.addEventListener("iceconnectionstatechange", () => pc.states.push([now(), `ice:${this.iceConnectionState}`]));
    }
    setRemoteDescription(description, ...rest) {
      const match = /a=candidate:\S+ \d+ \S+ \d+ (\S+) (\d+)/.exec(description?.sdp ?? "");
      if (match) this.__probe.endpoint = `${match[1]}:${match[2]}`;
      return super.setRemoteDescription(description, ...rest);
    }
    close() {
      this.__probe.closedByClient = now();
      return super.close();
    }
    createDataChannel(label, options) {
      const channel = super.createDataChannel(label, options);
      const c = { pc: this.__probe.id, label, created: now(), open: null, closing: null, close: null, error: null, rx: [], tx: [] };
      P.channels.push(c);
      channel.addEventListener("open", () => { c.open = now(); c.maxMessageSize = this.sctp?.maxMessageSize ?? null; });
      channel.addEventListener("closing", () => { c.closing = now(); });
      channel.addEventListener("close", () => { c.close = now(); });
      channel.addEventListener("error", event => { c.error = [now(), String(event?.error?.message ?? event?.error ?? "error")]; });
      channel.addEventListener("message", event => {
        const data = event.data;
        c.rx.push([now(), data?.byteLength ?? data?.size ?? data?.length ?? 0]);
      });
      const send = channel.send.bind(channel);
      channel.send = data => { c.tx.push([now(), data?.byteLength ?? data?.size ?? data?.length ?? 0, channel.bufferedAmount]); return send(data); };
      return channel;
    }
  }
  window.RTCPeerConnection = ProbePeerConnection;
};

const browserType = playwright[browserName];
let run = 0;
try {
  for (let round = 0; round < Number(roundsArg); round++) {
    const order = variants.map((_, i) => variants[(i + round) % variants.length]);
    for (const variant of order) {
      run++;
      const browser = await browserType.launch({ headless: true });
      const record = { label, browser: browserName, browserVersion: browser.version(), round, run, variant, wasm: wasmHash[variant].slice(0, 8), files: [], startedAt: Date.now() };
      try {
        const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, acceptDownloads: true });
        await context.addInitScript(probe);
        const page = await context.newPage();
        const pageErrors = [];
        page.on("pageerror", error => pageErrors.push(error.message));
        const consoleLines = [];
        const pageStart = Date.now();
        page.on("console", message => { if (["warning", "error"].includes(message.type()) && consoleLines.length < 5000) consoleLines.push([Date.now() - pageStart, message.type(), message.text().slice(0, 400)]); });
        await page.goto(`http://127.0.0.1:${port}/${variant}/`);
        await page.waitForFunction(() => document.getElementById("network-status")?.dataset.state === "ready", null, { timeout: 120_000 });
        for (const file of files) {
          const started = Date.now();
          const probeStart = await page.evaluate(() => Math.round(performance.now()));
          await page.evaluate(address => { location.hash = address; }, file.address);
          let result;
          try {
            await page.waitForFunction(address => window.__tryAutonomi?.address === address && (window.__tryAutonomi.sha256 || window.__tryAutonomi.error),
              file.address, { timeout: RUN_LIMIT_MS, polling: 250 });
            result = await page.evaluate(() => window.__tryAutonomi);
          } catch (error) {
            result = { error: `limit: ${String(error).slice(0, 120)}` };
          }
          const seconds = (Date.now() - started) / 1000;
          const fileLog = await page.evaluate(() => [...document.querySelectorAll("#log-lines > *")].map(line => line.textContent)).catch(() => []);
          record.files.push({ name: file.name, seconds, ok: result.sha256 === file.sha256, error: result.error ?? null,
            connections: result.connections, chunkRequests: result.chunkRequests, chunkBytes: result.chunkBytes, lookupBytes: result.lookupBytes, probeStart, log: fileLog });
          console.log(JSON.stringify({ run, round, variant, file: file.name, seconds, ok: result.sha256 === file.sha256, connections: result.connections, error: result.error ?? undefined }));
        }
        record.trace = await page.evaluate(() => window.__probe);
        record.pageErrors = pageErrors;
        record.console = consoleLines;
      } catch (error) {
        record.error = String(error);
        console.log(JSON.stringify({ run, round, variant, error: String(error).slice(0, 200) }));
      } finally {
        await browser.close();
      }
      record.endedAt = Date.now();
      appendFileSync(out, `${JSON.stringify(record)}\n`);
    }
  }
} finally {
  server.close();
}
