// Time to first frame for the Mandelbrot video through the SDK's createMediaSource(),
// one fresh browser per run, arms interleaved with the first arm rotating each round.
//
// usage: node stream-probe.mjs <browser> <rounds> <label> <arm>=<SDK dist dir>[,...]
import { createServer } from "node:http";
import { appendFileSync, mkdirSync, readFileSync } from "node:fs";
import { extname, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import * as playwright from "playwright";

const here = fileURLToPath(new URL(".", import.meta.url));
const [browserName = "chromium", roundsArg = "1", label = "stream", armsArg = ""] = process.argv.slice(2);
const arms = armsArg.split(",").map(arm => { const [name, dir] = arm.split("="); return { name, dir: resolve(dir) }; });
const ADDRESS = "efbf7a8adeed61e31eb5d865167ffe5b70676f08433301da772462c8032d60c0";
const PLAY_SECONDS = 30;
const SAMPLE_MS = 1_000;
const RUN_LIMIT_MS = 420_000;
const out = join(here, "runs", `${label}.jsonl`);
mkdirSync(join(here, "runs"), { recursive: true });

const types = { ".js": "text/javascript", ".wasm": "application/wasm", ".html": "text/html" };
// /<arm>/... serves that arm's dist; its service worker sits at /<arm>/autonomi-stream-sw.js
// and is registered with that arm's directory as its scope.
const server = createServer((req, res) => {
  const [, name, ...rest] = new URL(req.url, "http://localhost").pathname.split("/");
  const arm = arms.find(candidate => candidate.name === name);
  if (!arm) { res.writeHead(404).end(); return; }
  const path = rest.join("/");
  if (path === "") {
    res.writeHead(200, { "Content-Type": "text/html" }).end('<!doctype html><title>Stream probe</title><video id="v" muted playsinline></video>');
    return;
  }
  const file = resolve(arm.dir, path);
  if (!file.startsWith(arm.dir + sep)) { res.writeHead(403).end(); return; }
  try {
    res.writeHead(200, { "Content-Type": types[extname(file)] ?? "application/octet-stream", "Cache-Control": "no-store" }).end(readFileSync(file));
  } catch { res.writeHead(404).end(); }
});
await new Promise(done => server.listen(0, "127.0.0.1", done));
const origin = `http://127.0.0.1:${server.address().port}`;

let run = 0;
try {
  for (let round = 0; round < Number(roundsArg); round++) {
    for (const arm of arms.map((_, i) => arms[(i + round) % arms.length])) {
      run++;
      const browser = await playwright[browserName].launch({ headless: true, args: browserName === "chromium" ? ["--autoplay-policy=no-user-gesture-required"] : [] });
      const record = { label, browser: browserName, version: browser.version(), round, run, arm: arm.name };
      try {
        const page = await browser.newPage();
        const errors = [];
        page.on("pageerror", error => errors.push(error.message));
        await page.goto(`${origin}/${arm.name}/`);
        const result = await Promise.race([
          page.evaluate(async ({ ADDRESS, PLAY_SECONDS, SAMPLE_MS, scope }) => {
            const t0 = performance.now();
            const at = () => Math.round(performance.now() - t0) / 1000;
            const { AutonomiClient } = await import(`${scope}index.js`);
            const client = await AutonomiClient.connect();
            const connected = at();
            const video = document.getElementById("v");
            const stalls = [];
            let waitingSince;
            video.addEventListener("waiting", () => { waitingSince ??= performance.now(); });
            video.addEventListener("playing", () => {
              if (waitingSince !== undefined) stalls.push({ at: at(), seconds: Math.round(performance.now() - waitingSince) / 1000, position: video.currentTime });
              waitingSince = undefined;
            });
            const requested = performance.now();
            const source = await client.createMediaSource(ADDRESS, { serviceWorkerUrl: `${scope}autonomi-stream-sw.js`, scope });
            const sourceReady = (performance.now() - requested) / 1000;
            video.src = source.url;
            await video.play();
            await new Promise((done, fail) => {
              const check = () => { if (video.currentTime > 0) done(); };
              video.addEventListener("timeupdate", check);
              video.addEventListener("error", () => fail(new Error(`media error ${video.error?.code}: ${video.error?.message}`)));
            });
            const firstFrame = (performance.now() - requested) / 1000;
            const samples = [];
            const playStart = performance.now();
            while (performance.now() - playStart < PLAY_SECONDS * 1000 && !video.ended) {
              await new Promise(done => setTimeout(done, SAMPLE_MS));
              const ahead = video.buffered.length ? video.buffered.end(video.buffered.length - 1) - video.currentTime : 0;
              samples.push([at(), Math.round(video.currentTime * 10) / 10, Math.round(ahead * 10) / 10]);
            }
            const played = video.currentTime;
            const finished = (performance.now() - requested) / 1000;
            source.close();
            client.close();
            return { connected, sourceReady, firstFrame, finished, ended: video.ended, duration: video.duration, played, stalls, samples };
          }, { ADDRESS, PLAY_SECONDS, SAMPLE_MS, scope: `/${arm.name}/` }),
          new Promise((_, fail) => setTimeout(() => fail(new Error("run limit")), RUN_LIMIT_MS)),
        ]);
        Object.assign(record, result, { pageErrors: errors });
        console.log(JSON.stringify({ run, round, arm: arm.name, connect: result.connected, sourceReady: +result.sourceReady.toFixed(2), firstFrame: +result.firstFrame.toFixed(2),
          finished: result.ended ? +result.finished.toFixed(1) : null, played: +result.played.toFixed(1), stalls: result.stalls.length,
          stallSeconds: +result.stalls.reduce((sum, stall) => sum + stall.seconds, 0).toFixed(1), errors: errors.length }));
      } catch (error) {
        record.error = String(error).slice(0, 300);
        console.log(JSON.stringify({ run, round, arm: arm.name, error: record.error }));
      } finally {
        await browser.close();
      }
      appendFileSync(out, `${JSON.stringify(record)}\n`);
    }
  }
} finally {
  server.close();
}
