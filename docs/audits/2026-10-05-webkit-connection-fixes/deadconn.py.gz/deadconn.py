import json, sys, statistics
rows = []
for path in sys.argv[1:]:
    for l in open(path):
        r = json.loads(l)
        if "trace" not in r: continue
        pcs = r["trace"]["pcs"]; chans = r["trace"]["channels"]
        end = max(f["probeStart"] + f["seconds"] * 1000 for f in r["files"])
        failed = sends = late_open = sends_disc = 0
        for p in pcs:
            tf = next((t for t, s in p["states"] if s == "failed"), None)
            td = next((t for t, s in p["states"] if s == "disconnected"), None)
            mine = [c for c in chans if c["pc"] == p["id"]]
            if td is not None:
                sends_disc += sum(1 for c in mine for t, *_ in c["tx"] if td < t < (tf or 1e15))
            if tf is None or tf > end: continue
            failed += 1
            for c in mine:
                if c["open"] and c["open"] > tf: late_open += 1
                sends += sum(1 for t, *_ in c["tx"] if t > tf)
        secs = {f["name"][:4]: f["seconds"] for f in r["files"]}
        rows.append((r["variant"], r["run"], secs.get("Welc", 0), secs.get("Mand", 0), len(pcs), failed, sends, late_open, sends_disc))
print("variant run  text_s  video_s  pcs failed sends_after_fail late_opens sends_while_disconnected")
for row in sorted(rows):
    print("%-9s %3d %7.1f %8.1f %4d %6d %16d %10d %24d" % row)
