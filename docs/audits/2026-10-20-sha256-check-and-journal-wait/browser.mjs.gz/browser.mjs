// Real-Chromium devnet run for ant-browser-sdk 317a634: the 2026-10-15 pointer, manifest and
// streaming-save checks, plus manifest sha256 checks on download and wallets waiting for the journal.
// Usage: node browser.mjs <output directory>
import { chromium } from '/Users/mick/RustroverProjects/ant-client-wasm-large-files/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash, randomBytes } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root = '/Users/mick/RustroverProjects/ant-browser-sdk-pr7-bab6beb';
const nodeDir = '/Users/mick/RustroverProjects/ant-node-sdk-devnet-20261015';
const out = process.argv[2];
assert.ok(out, 'usage: node browser.mjs <output directory>');
await mkdir(out, { recursive: true });
const info = await (await fetch('http://127.0.0.1:39970/api/info')).json();
const manifest = await (await fetch('http://127.0.0.1:39970/api/browser-manifest.json')).json();
// The public Anvil development key is used only against a local Anvil chain.
assert.equal(info.evm.network, 'local-anvil');
assert.ok(['localhost', '127.0.0.1'].includes(new URL(info.evm.rpc_url).hostname));
const provenance = JSON.parse(await readFile(`${root}/src/wasm/source.json`, 'utf8'));
const sdkRevision = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
const nodeRevision = execFileSync('git', ['-C', nodeDir, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
// A fresh 16-byte prefix per file, so no earlier run has stored its records and every upload pays.
const fresh = () => { const bytes = Array.from({ length: 13056 }, (_, i) => (i * 37 + 19) % 256); randomBytes(16).forEach((b, i) => { bytes[i] = b; }); return bytes; };
const contents = { public: fresh(), private: fresh() };
const sha256s = Object.fromEntries(Object.entries(contents).map(([key, bytes]) => [key, createHash('sha256').update(Uint8Array.from(bytes)).digest('hex')]));
// Well-formed, and not what the bytes hash to.
const wrongSha256s = Object.fromEntries(Object.entries(sha256s).map(([key, hash]) => [key, (hash[0] === '0' ? '1' : '0') + hash.slice(1)]));
const browser = await chromium.launch({ headless: true, args: ['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/'] });
try {
  const page = await browser.newPage(); const pageErrors = [], wasmHashes = [];
  page.on('pageerror', error => pageErrors.push(error.message));
  page.on('console', message => { if (message.type() === 'log') console.log(message.text()); });
  page.on('response', async r => { if (new URL(r.url()).pathname.endsWith('.wasm')) wasmHashes.push(createHash('sha256').update(await r.body()).digest('hex')); });
  await page.goto('http://127.0.0.1:39971', { waitUntil: 'networkidle' });
  const result = await page.evaluate(async ({ root, manifest, rpc, contents, sha256s, wrongSha256s }) => {
    const sdk = await import(`/@fs${root}/dist/index.js`);
    const { createEthersPaymentProvider } = await import(`/@fs${root}/dist/ethers.js`);
    const assert = (value, message) => { if (!value) throw Error(message); };
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const errorText = error => { let text = ''; for (let e = error; e; e = e.cause) text += ` ${e.message}`; return text; };
    const payment = createEthersPaymentProvider({ privateKey: '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80', rpcUrl: rpc });
    const expectedPaymentNetwork = { chainId: manifest.payment.chain_id, paymentTokenAddress: manifest.payment.payment_token_address, paymentVaultAddress: manifest.payment.payment_vault_address };
    const connected = await sdk.AutonomiClient.connectNetwork({ id: 'api-probe', seeds: manifest.endpoints.map(e => e.multiaddr), payment: expectedPaymentNetwork }, { payment });
    // Match upstream's devnet harness pacing: nodes close sessions above 16 requests/s.
    // Local Anvil confirms instantly, unlike a normal wallet confirmation.
    const pacedMethods = new Set(['upload', 'download', 'downloadAndSave', 'streamAndSave', 'getPointer', 'resolvePointer', 'pointerFinality', 'createPointer', 'updatePointer', 'transferPointer', 'resumePointer']);
    const client = new Proxy(connected, { get(target, key) { const value = Reflect.get(target, key, target); if (typeof value !== 'function') return value; return pacedMethods.has(key) ? async (...args) => { await sleep(1500); return value.apply(target, args); } : value.bind(target); } });

    // The Ethers wallet, observed: when it broadcasts, when the SDK's submitted() settles, and when it returns.
    // A journal that takes 1.5 s to persist the broadcast shows whether the wallet waited for it.
    const t0 = performance.now(); const now = () => Math.round(performance.now() - t0);
    const flows = {};
    const observed = label => ({ ...payment, pay: async (network, quotes, context) => {
      const flow = { checkpointsWithoutHash: 0 }; (flows[label] ??= []).push(flow);
      const watched = { ...context, submitted: async submission => {
        flow.transactionHash = submission.transactionHash; flow.broadcastMs = now();
        await context.submitted(submission); flow.submittedSettledMs = now();
      } };
      const receipt = await payment.pay(network, quotes, watched); flow.walletReturnedMs = now();
      return receipt;
    } });
    const slowJournal = (label, write = async () => {}) => async value => {
      await write(value);
      const flow = flows[label]?.find(f => f.broadcastMs !== undefined && f.journalPersistedMs === undefined);
      if (!flow) return;
      // A pointer checkpoint is JSON; an upload checkpoint holds hex MessagePack, where the hash is a string.
      const hash = flow.transactionHash.toLowerCase();
      const hashAsHexString = Array.from(new TextEncoder().encode(flow.transactionHash), b => b.toString(16).padStart(2, '0')).join('');
      if (!value.toLowerCase().includes(hash.replace(/^0x/, '')) && !value.toLowerCase().includes(hashAsHexString)) { flow.checkpointsWithoutHash++; return; }
      await sleep(1500); flow.journalPersistedMs = now();
    };

    const opfs = await navigator.storage.getDirectory();
    const directory = await opfs.getDirectoryHandle('sdk-api-probe', { create: true });
    const exists = name => directory.getFileHandle(name).then(() => true, () => false);
    const files = []; const phases = [];
    try {
      for (const visibility of ['public', 'private']) {
        const label = `upload ${visibility}`;
        const bytes = Uint8Array.from(contents[visibility]), sha256 = sha256s[visibility], wrongSha256 = wrongSha256s[visibility];
        const same = actual => actual.length === bytes.length && actual.every((n, i) => n === bytes[i]);
        const uploaded = await client.upload(bytes, { name: `${visibility}.bin`, visibility, paymentMode: 'single', payment: observed(label), onCheckpoint: slowJournal(label) });
        files.push(uploaded.file);
        const reference = visibility === 'public' ? { kind: 'public', address: uploaded.file.address } : { kind: 'embedded', dataMap: uploaded.file.dataMap };
        // The creator records the hash in upper case; the core normalizes it. A size hint is
        // display-only on a public entry, and the core refuses one contradicting an embedded root map.
        const sizeHint = visibility === 'public' ? { size: 1 } : {};
        const created = await sdk.createManifest({ name: 'exports', entries: [{ ...reference, ...sizeHint, path: `folder/${visibility}.bin`, sha256: sha256.toUpperCase() }] });
        const decoded = await sdk.decodeManifest(created.bytes); const parsed = await sdk.parseManifestLink(created.link);
        assert(parsed.kind === 'manifest' && parsed.manifest.entries[0].address === decoded.entries[0].address, 'manifest link mismatch');
        const entry = decoded.entries[0];
        assert(entry.sha256 === sha256 && parsed.manifest.entries[0].sha256 === sha256, 'recorded sha256');
        if (visibility === 'private') assert(entry.knownSize === bytes.length, 'derived size');
        const wrongCreated = await sdk.createManifest({ name: 'exports', entries: [{ ...reference, path: `folder/${visibility}.bin`, sha256: wrongSha256 }] });
        const wrongEntry = (await sdk.decodeManifest(wrongCreated.bytes)).entries[0];
        assert(wrongEntry.sha256 === wrongSha256, 'recorded wrong sha256');

        // download() returns bytes that meet the claim and refuses bytes that do not.
        const downloaded = await client.download(entry);
        assert(same(downloaded.bytes) && downloaded.blob.size === bytes.length && downloaded.hash === uploaded.file.blake3, 'download bytes');
        let refused; try { await client.download(wrongEntry); } catch (error) { refused = error; }
        assert(refused?.code === 'DOWNLOAD_FAILED' && errorText(refused).includes(`expected ${wrongSha256}, got ${sha256}`), `download mismatch: ${errorText(refused)}`);

        // downloadAndSave() saves bytes that meet the claim and opens no writable for bytes that do not.
        const savedHandle = await directory.getFileHandle(`${visibility}-saved.bin`, { create: true });
        window.showSaveFilePicker = async () => savedHandle;
        const saved = await client.downloadAndSave(entry, { suggestedName: `${visibility}.bin` });
        assert(saved.save.method === 'file-picker' && same(new Uint8Array(await (await savedHandle.getFile()).arrayBuffer())), 'downloadAndSave bytes');
        const refusedHandle = await directory.getFileHandle(`${visibility}-refused.bin`, { create: true });
        let writables = 0;
        window.showSaveFilePicker = async () => ({ kind: 'file', name: refusedHandle.name,
          createWritable: (...args) => { writables++; return refusedHandle.createWritable(...args); },
          getFile: () => refusedHandle.getFile(), remove: () => refusedHandle.remove() });
        let saveRefused; try { await client.downloadAndSave(wrongEntry, { suggestedName: `${visibility}.bin` }); } catch (error) { saveRefused = error; }
        assert(saveRefused?.code === 'DOWNLOAD_FAILED' && writables === 0, `downloadAndSave mismatch: ${errorText(saveRefused)}`);
        // The SDK removes the empty picked file without awaiting it.
        let refusedFileLeft = true;
        for (let i = 0; i < 40 && refusedFileLeft; i++) { refusedFileLeft = await exists(`${visibility}-refused.bin`); if (refusedFileLeft) await sleep(50); }
        assert(!refusedFileLeft, 'empty picked file removed');

        // Streaming saves never hold the whole file, so they do not check the claim.
        const streamHandle = await directory.getFileHandle(`${visibility}.bin`, { create: true });
        let picked = false;
        window.showSaveFilePicker = async () => { picked = true; return streamHandle; };
        const streamed = await client.streamAndSave(entry, { suggestedName: `${visibility}.bin` });
        assert(picked && streamed.bytesWritten === bytes.length && same(new Uint8Array(await (await streamHandle.getFile()).arrayBuffer())), 'stream save bytes');
        assert(streamed.hash === uploaded.file.blake3, 'stream save hash');
        const wrongStreamHandle = await directory.getFileHandle(`${visibility}-unchecked.bin`, { create: true });
        window.showSaveFilePicker = async () => wrongStreamHandle;
        const unchecked = await client.streamAndSave(wrongEntry, { suggestedName: `${visibility}.bin` });
        assert(unchecked.bytesWritten === bytes.length, 'stream save ignores the claim');

        phases.push({ visibility, bytes: streamed.bytesWritten, hash: streamed.hash, sha256: entry.sha256, linkRecommended: created.linkRecommended, manifestBytes: created.bytes.length,
          download: { bytes: downloaded.bytes.length, matchesClaim: true }, downloadMismatch: { code: refused.code },
          downloadAndSave: { method: saved.save.method }, downloadAndSaveMismatch: { code: saveRefused.code, writables, refusedFileLeft },
          streamAndSaveIgnoresClaim: { bytesWritten: unchecked.bytesWritten },
          manifestBase64: btoa(String.fromCharCode(...created.bytes)), wrongManifestBase64: btoa(String.fromCharCode(...wrongCreated.bytes)) });
        console.log(`files ${visibility} passed`);
      }
      const address = files[0].address;
      const owner = crypto.getRandomValues(new Uint8Array(32)), recipient = crypto.getRandomValues(new Uint8Array(32));
      const pointer = await sdk.pointerAddress(owner), recipientPointer = await sdk.pointerAddress(recipient);
      const journals = {};
      const persist = key => async value => { const file = await directory.getFileHandle(`${key}.json`, { create: true }); const writable = await file.createWritable(); await writable.write(value); await writable.close(); journals[key] = value; };
      assert(await client.getPointer(pointer) === null, 'missing pointer');
      const first = await client.createPointer({ ownerSeed: owner, kind: 'chunk', target: address, payment: observed('pointer create'), onCheckpoint: slowJournal('pointer create', persist('first')) });
      assert(first.pointer.counter === '0' && first.pointer.address === pointer, 'create');
      assert((await client.getPointer(pointer)).stateId === first.pointer.stateId, 'get');
      assert((await client.resolvePointer(pointer)).target === address, 'resolve');
      const second = await client.updatePointer({ ownerSeed: owner, kind: 'chunk', target: address, onCheckpoint: persist('second') });
      assert(second.pointer.counter === '1', 'update');
      const open = await client.pointerFinality(pointer); assert(open.status === 'open' && open.counter === '1', 'open finality');
      await client.createPointer({ ownerSeed: recipient, kind: 'chunk', target: address, onCheckpoint: persist('recipient') });
      const transferred = await client.transferPointer({ ownerSeed: owner, recipient: recipientPointer, onCheckpoint: persist('transfer') });
      assert(transferred.pointer.counter === '18446744073709551615', 'full width final counter');
      const finality = await client.pointerFinality(pointer); assert(finality.status === 'final' && finality.majority.transferredTo === recipientPointer, 'finality');
      assert((await client.resolvePointer(pointer)).target === address, 'transfer resolution');
      const stored = await client.resumePointer(journals.transfer, { onCheckpoint: persist('transfer-retry') });
      assert(stored.stateId === transferred.pointer.stateId, 'paid proof replay');
      console.log('pointer create/update/transfer/finality passed');
      // A wallet that loses its confirmation after a real broadcast: the write observes the broadcast on this page and stores it.
      const interruptedOwner = crypto.getRandomValues(new Uint8Array(32)); let payCount = 0;
      const interrupted = { ...payment, pay: async (...args) => { payCount++; await payment.pay(...args); throw Error('probe: lost confirmation after real transaction'); } };
      const confirmed = await client.createPointer({ ownerSeed: interruptedOwner, kind: 'chunk', target: address, payment: interrupted, onCheckpoint: persist('interrupted') });
      assert(payCount === 1 && confirmed.pointer.address === await sdk.pointerAddress(interruptedOwner) && confirmed.pointer.counter === '0', 'same-page confirmation');
      assert((await client.getPointer(confirmed.pointer.address)).stateId === confirmed.pointer.stateId, 'same-page stored state');
      assert(JSON.parse(journals.interrupted).paid, 'same-page paid checkpoint');
      phases.push({ pointers: { fileAddress: address, address: pointer, created: first.pointer.counter, updated: second.pointer.counter, transferred: transferred.pointer.counter, finality, paidRetry: stored.stateId, samePageConfirmed: confirmed.pointer.address, payCount } });
      console.log('pointer same-page confirmation passed');
      // A caller-supplied writable is cancelled without buffering or leaving a lock.
      const controller = new AbortController(); let aborts = 0;
      const stream = new WritableStream({ write() { controller.abort(); }, abort() { aborts++; } });
      let cancelled = false; try { await client.streamAndSave(files[0], { destination: stream, signal: controller.signal }); } catch (error) { cancelled = error.name === 'AbortError'; }
      assert(cancelled && !stream.locked && aborts === 1, 'stream cancellation cleanup');
      phases.push({ streamCancellation: { cancelled, aborts, locked: stream.locked } });
      phases.push({ journalWaits: flows });
      return phases;
    } finally { client.close(); await opfs.removeEntry('sdk-api-probe', { recursive: true }); }
  }, { root, manifest, rpc: info.evm.rpc_url, contents, sha256s, wrongSha256s });

  // Each observed wallet saw the journal persist its broadcast before submitted() settled, and returned after.
  const flows = result.find(entry => entry.journalWaits).journalWaits;
  assert.deepEqual(Object.keys(flows).sort(), ['pointer create', 'upload private', 'upload public']);
  for (const [label, calls] of Object.entries(flows)) {
    assert.ok(calls.length > 0, label);
    for (const flow of calls) {
      assert.ok(flow.journalPersistedMs !== undefined, `${label}: no checkpoint carried ${flow.transactionHash}`);
      assert.ok(flow.broadcastMs < flow.journalPersistedMs && flow.journalPersistedMs <= flow.submittedSettledMs && flow.submittedSettledMs <= flow.walletReturnedMs, `${label}: ${JSON.stringify(flow)}`);
      assert.ok(flow.submittedSettledMs - flow.broadcastMs >= 1500, `${label}: the wallet did not wait for the slow journal`);
    }
  }
  // A page lost after its broadcast was journaled, before the write confirmed or stored: a fresh page
  // recovers it from the checkpoint by observing the original transaction, and never pays.
  const watch = page => { page.on('pageerror', error => pageErrors.push(error.message));
    page.on('response', async r => { if (new URL(r.url()).pathname.endsWith('.wasm')) wasmHashes.push(createHash('sha256').update(await r.body()).digest('hex')); }); };
  const { fileAddress } = result.find(entry => entry.pointers).pointers;
  const lostPage = await browser.newPage(); watch(lostPage);
  await lostPage.goto('http://127.0.0.1:39971', { waitUntil: 'networkidle' });
  await lostPage.evaluate(async ({ root, manifest, rpc, fileAddress }) => {
    const sdk = await import(`/@fs${root}/dist/index.js`);
    const { createEthersPaymentProvider } = await import(`/@fs${root}/dist/ethers.js`);
    const payment = createEthersPaymentProvider({ privateKey: '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80', rpcUrl: rpc });
    const client = await sdk.AutonomiClient.connectNetwork({ id: 'api-probe-lost', seeds: manifest.endpoints.map(e => e.multiaddr), payment: { chainId: manifest.payment.chain_id, paymentTokenAddress: manifest.payment.payment_token_address, paymentVaultAddress: manifest.payment.payment_vault_address } }, { payment });
    await new Promise(resolve => setTimeout(resolve, 1500));
    const owner = crypto.getRandomValues(new Uint8Array(32));
    const lost = window.lostPage = { address: await sdk.pointerAddress(owner), payCount: 0, journaled: false };
    // The wallet broadcasts, waits for submitted(), then never returns: the page is lost before confirmation.
    const hanging = { ...payment, pay: async (network, quotes, context) => { lost.payCount++; return payment.pay(network, quotes, { ...context,
      submitted: async submission => { await context.submitted(submission); lost.transactionHash = submission.transactionHash; lost.journaled = true; await new Promise(() => {}); } }); } };
    void client.createPointer({ ownerSeed: owner, kind: 'chunk', target: fileAddress, payment: hanging, onCheckpoint: value => { lost.checkpoint = value; } })
      .then(() => { lost.error = 'the write completed'; }, error => { lost.error = String(error); });
  }, { root, manifest, rpc: info.evm.rpc_url, fileAddress });
  await lostPage.waitForFunction(() => window.lostPage?.journaled || window.lostPage?.error, null, { timeout: 120000 });
  const lost = await lostPage.evaluate(() => window.lostPage);
  await lostPage.close();
  assert.equal(lost.error, undefined);
  const lostJournal = JSON.parse(lost.checkpoint);
  // submitted() settled only once the checkpoint held the broadcast.
  assert.ok(!lostJournal.paid && lostJournal.submissions.some(s => s.transactionHash === lost.transactionHash), 'lost page checkpoint');
  const recoveryPage = await browser.newPage(); watch(recoveryPage);
  await recoveryPage.goto('http://127.0.0.1:39971', { waitUntil: 'networkidle' });
  const recovered = await recoveryPage.evaluate(async ({ root, manifest, rpc, checkpoint }) => {
    const sdk = await import(`/@fs${root}/dist/index.js`);
    const { createEthersPaymentProvider } = await import(`/@fs${root}/dist/ethers.js`);
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const payment = createEthersPaymentProvider({ privateKey: '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80', rpcUrl: rpc });
    let payCalls = 0;
    // Recovery may only observe the original transaction; any payment attempt fails the run.
    const observeOnly = { ...payment, pay: async () => { payCalls++; throw Error('probe: recovery must not pay'); }, payMerkle: async () => { payCalls++; throw Error('probe: recovery must not pay'); } };
    const client = await sdk.AutonomiClient.connectNetwork({ id: 'api-probe-recovery', seeds: manifest.endpoints.map(e => e.multiaddr), payment: { chainId: manifest.payment.chain_id, paymentTokenAddress: manifest.payment.payment_token_address, paymentVaultAddress: manifest.payment.payment_vault_address } }, { payment: observeOnly });
    try {
      await sleep(1500);
      const journals = [];
      const pointer = await client.resumePointer(checkpoint, { payment: observeOnly, onCheckpoint: value => { journals.push(value); } });
      await sleep(1500);
      const read = await client.getPointer(pointer.address);
      return { address: pointer.address, counter: pointer.counter, stateId: pointer.stateId, readStateId: read?.stateId, payCalls, paidCheckpoint: journals.some(j => JSON.parse(j).paid !== undefined) };
    } finally { client.close(); }
  }, { root, manifest, rpc: info.evm.rpc_url, checkpoint: lost.checkpoint });
  assert.ok(recovered.address === lost.address && recovered.counter === '0' && recovered.readStateId === recovered.stateId, 'lost page recovered');
  assert.ok(lost.payCount === 1 && recovered.payCalls === 0 && recovered.paidCheckpoint, 'lost page recovered without paying');
  result.push({ lostPageRecovery: { address: recovered.address, transactionHash: lost.transactionHash, lostPagePayments: lost.payCount, recoveryPagePayments: recovered.payCalls, stateId: recovered.stateId } });
  console.log('pointer lost-page recovery passed');
  for (const entry of result.filter(entry => entry.manifestBase64)) {
    await writeFile(`${out}/${entry.visibility}.ant`, Buffer.from(entry.manifestBase64, 'base64'));
    await writeFile(`${out}/${entry.visibility}-wrong-sha256.ant`, Buffer.from(entry.wrongManifestBase64, 'base64'));
    delete entry.manifestBase64; delete entry.wrongManifestBase64;
  }
  assert.deepEqual(pageErrors, []); assert.ok(wasmHashes.length > 0 && wasmHashes.every(hash => hash === provenance.wasmSha256));
  const summary = { browser: browser.version(), sdkRevision, wasm: provenance, node: nodeRevision, sha256s, wrongSha256s, prefixes: Object.fromEntries(Object.entries(contents).map(([key, bytes]) => [key, Buffer.from(bytes.slice(0, 16)).toString('hex')])), result, pageErrors, wasmHashes };
  await writeFile(`${out}/browser-summary.json`, JSON.stringify(summary, null, 2)); console.log(JSON.stringify(summary));
} finally { await browser.close(); }
