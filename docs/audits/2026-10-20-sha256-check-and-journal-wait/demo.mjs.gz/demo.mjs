// The all-in-one demo's manifest export and stream-to-disk buttons against the devnet run's public file.
// Usage: node demo.mjs <output directory>
import { chromium } from '/Users/mick/RustroverProjects/ant-client-wasm-large-files/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const root = '/Users/mick/RustroverProjects/ant-browser-sdk-pr7-bab6beb';
const out = process.argv[2];
const manifest = await (await fetch('http://127.0.0.1:39970/api/browser-manifest.json')).json();
const publicFile = JSON.parse(await readFile(`${out}/native-show-public.json`, 'utf8')).entries[0];
const prefix = [...Buffer.from(JSON.parse(await readFile(`${out}/browser-summary.json`, 'utf8')).prefixes.public, 'hex')];
const browser = await chromium.launch({ headless: true, args: ['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/'] });
try {
  const page = await browser.newPage({ acceptDownloads: true }); const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.addInitScript(() => { window.showSaveFilePicker = async () => { const root = await navigator.storage.getDirectory(); return root.getFileHandle('sdk-api-demo.bin', { create: true }); }; });
  await page.goto('http://127.0.0.1:39971', { waitUntil: 'networkidle' });
  await page.locator('#bootstrap').fill(manifest.endpoints[0].multiaddr); await page.locator('#connect').click();
  await page.waitForFunction(() => document.querySelector('#connection').value.startsWith('Connected'));
  await page.locator('#address').fill(publicFile.address);
  const saved = page.waitForEvent('download'); await page.locator('#export-manifest').click();
  const download = await saved; const exported = await readFile(await download.path());
  const link = await page.locator('#share-link').inputValue();
  const decoded = await page.evaluate(async ({ root, bytes, link }) => { const sdk = await import(`/@fs${root}/dist/index.js`); return { file: await sdk.decodeManifest(Uint8Array.from(bytes)), link: await sdk.parseManifestLink(link) }; }, { root, bytes: [...exported], link });
  assert.equal(decoded.file.entries[0].address, publicFile.address); assert.deepEqual(decoded.link.manifest, decoded.file);
  await page.locator('#download-to-disk').click();
  await page.waitForFunction(() => document.querySelector('#log').textContent.includes('Verified and saved 13056 bytes'), null, { timeout: 60000 });
  const disk = await page.evaluate(async prefix => { const root = await navigator.storage.getDirectory(); const handle = await root.getFileHandle('sdk-api-demo.bin'); const content = new Uint8Array(await (await handle.getFile()).arrayBuffer()); await root.removeEntry('sdk-api-demo.bin'); return { size: content.length, matches: content.every((n, i) => n === (i < prefix.length ? prefix[i] : (i * 37 + 19) % 256)) }; }, prefix);
  assert.deepEqual(disk, { size: 13056, matches: true }); assert.deepEqual(errors, []);
  const result = { exportedManifestBytes: exported.length, linkMatchesFile: true, disk, errors, browser: browser.version() };
  await writeFile(`${out}/demo-summary.json`, JSON.stringify(result, null, 2)); console.log(JSON.stringify(result));
} finally { await browser.close(); }
