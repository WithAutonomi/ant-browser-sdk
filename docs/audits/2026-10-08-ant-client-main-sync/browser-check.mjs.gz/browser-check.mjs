import { chromium } from '/private/tmp/ant-client-pr6-main-20261008/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import init, { encryptPublicFile } from '/Users/mick/RustroverProjects/ant-client-browser-sdk-pr6-main-sync/src/wasm/ant_core.js';
const sdkRoot = '/Users/mick/RustroverProjects/ant-client-browser-sdk-pr6-main-sync';
const sdkUrl = `/@fs${sdkRoot}/dist/index.js`;
const origin = 'http://127.0.0.1:39771';
const info = await (await fetch('http://127.0.0.1:39770/api/info')).json();
const manifest = await (await fetch('http://127.0.0.1:39770/api/browser-manifest.json')).json();
assert.equal(info.evm.network, 'local-anvil');
assert.ok(['localhost','127.0.0.1'].includes(new URL(info.evm.rpc_url).hostname));
const source = JSON.parse(await readFile(`${sdkRoot}/src/wasm/source.json`, 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
await init({ module_or_path: await readFile(`${sdkRoot}/src/wasm/ant_core_bg.wasm`) });
// Probe-only msgpack encoder for the normative ADR-0006 v1 fixture fields.
function pack(value) {
  if (typeof value === 'number') { if (value < 128) return Buffer.from([value]); const out=Buffer.alloc(5); out[0]=0xce; out.writeUInt32BE(value,1); return out; }
  if (typeof value === 'string') { const b=Buffer.from(value); assert.ok(b.length<32); return Buffer.concat([Buffer.from([0xa0+b.length]),b]); }
  if (Buffer.isBuffer(value)) { const h=Buffer.alloc(3); h[0]=0xc5; h.writeUInt16BE(value.length,1); return Buffer.concat([h,value]); }
  if (Array.isArray(value)) return Buffer.concat([Buffer.from([0x90+value.length]),...value.map(pack)]);
  const entries=Object.entries(value); return Buffer.concat([Buffer.from([0x80+entries.length]),...entries.flatMap(([k,v])=>[pack(k),pack(v)])]);
}
const browser = await chromium.launch({headless:true,args:['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/']});
const summary={browser:browser.version(),sdkBase:'98e0933',wasm:source.revision,wasmSha256:source.wasmSha256,node:'26129a2611cac08f9f53a557f91fb8806b40a1cc',phases:[]};
try {
  for (const visibility of ['public','private']) {
    const content=Buffer.from(Array.from({length:13056},(_,i)=>(i*37+(visibility==='public'?11:19))%256));
    const encrypted=encryptPublicFile(content);
    const packedRecords=Buffer.concat(encrypted.chunks.map(c=>{const size=Buffer.alloc(4); size.writeUInt32BE(c.src_size); return Buffer.concat([Buffer.from(c.dst_hash,'hex'),Buffer.from(c.src_hash,'hex'),size]);}));
    const manifestBytes=Buffer.concat([Buffer.from([0xc1,0x41,0x4e,0x54,1]),pack({name:'probe',entries:[{path:`${visibility}.bin`,size:1,source:{Embedded:{data_map:{chunks:packedRecords}}}}]})]);
    const publicBytes=Buffer.concat([Buffer.from([0xc1,0x41,0x4e,0x54,1]),pack({entries:[{path:`${visibility}.bin`,source:{Public:{address:Buffer.from(encrypted.address,'hex')}}}]})]);
    const context=await browser.newContext({acceptDownloads:true}); const page=await context.newPage();
    const errors=[], consoleErrors=[], wasmHashes=[];
    page.on('pageerror',e=>errors.push(e.message));
    page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
    page.on('response',async r=>{if(new URL(r.url()).pathname.endsWith('.wasm'))wasmHashes.push(sha(await r.body()));});
    await page.addInitScript(()=>{window.showSaveFilePicker=undefined;});
    await page.goto(origin);
    await page.locator('#bootstrap').fill(manifest.endpoints[0].multiaddr);
    await page.locator('#connect').click();
    await page.waitForFunction(()=>document.querySelector('#connection').value.startsWith('Connected'),null,{timeout:60000});
    await page.locator('#payment-rpc').fill(info.evm.rpc_url);
    await page.locator('#wallet').fill('0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80');
    await page.locator('#visibility').selectOption(visibility);
    await page.locator('#upload-input').setInputFiles({name:`${visibility}.bin`,mimeType:'application/octet-stream',buffer:content});
    await page.locator('#upload').click();
    await page.waitForFunction(()=>/Uploaded (private|.* as )/.test(document.querySelector('#log').textContent),null,{timeout:180000});
    if (visibility==='public') assert.equal(await page.locator('#address').inputValue(),encrypted.address);
    if (visibility==='private') {
      const saved=page.waitForEvent('download'); await page.locator('#save-datamap').click();
      const file=await saved; const datamap=await readFile(await file.path());
      assert.ok(datamap.length>0);
      await page.locator('#datamap-input').setInputFiles({name:'private.bin.datamap',mimeType:'application/octet-stream',buffer:datamap});
      await page.waitForFunction(()=>document.querySelector('#log').textContent.includes('Loaded the private DataMap'));
    }
    const saved=page.waitForEvent('download',{timeout:180000}); await page.locator('#download').click();
    const file=await saved; assert.deepEqual(await readFile(await file.path()),content);
    // Reload releases the demo's client before exercising a fresh SDK client.
    await page.reload();
    const result=await page.evaluate(async ({sdkUrl,seed,payment,bytes,publicBytes,content,visibility})=>{
      const sdk=await import(sdkUrl);
      const embedded=(await sdk.decodeManifest(Uint8Array.from(bytes))).entries[0];
      const link=`ant://manifest/${btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'')}`;
      const parsed=await sdk.parseManifestLink(link);
      if(parsed.kind!=='manifest'||parsed.manifest.entries[0].address!==embedded.address)throw Error('manifest link identity mismatch');
      const publicEntry=(await sdk.decodeManifest(Uint8Array.from(publicBytes))).entries[0];
      const client=await sdk.AutonomiClient.connect(seed,{paymentNetwork:{chainId:payment.chain_id,paymentTokenAddress:payment.payment_token_address,paymentVaultAddress:payment.payment_vault_address}});
      const match=bytes=>bytes.length===content.length&&bytes.every((x,i)=>x===content[i]);
      let reader,media;
      try {
        const download=await client.download(embedded); if(!match(download.bytes))throw Error('embedded download mismatch');
        if(visibility==='public') {const download=await client.download(publicEntry);if(!match(download.bytes))throw Error('public manifest download mismatch');}
        reader=await client.openFile(embedded);
        for(const [start,length] of [[0,4096],[6000,1024],[content.length-64,64]]){const actual=await reader.read(start,length);if(!actual.every((x,i)=>x===content[start+i])||actual.length!==length)throw Error('reader range mismatch');}
        reader.close(); reader=undefined;
        media=await client.createMediaSource(embedded,{contentType:'video/mp4'});
        for(const [start,length] of [[0,4096],[content.length-64,64]]){const response=await fetch(media.url,{headers:{Range:`bytes=${start}-${start+length-1}`}});const actual=new Uint8Array(await response.arrayBuffer());if(response.status!==206||actual.length!==length||!actual.every((x,i)=>x===content[start+i]))throw Error('media range mismatch');}
        return {address:embedded.address,knownSize:embedded.knownSize,creatorSize:embedded.size,downloadBytes:download.bytes.length,rangeReads:3,mediaRanges:2};
      }finally{reader?.close();media?.close();client.close();}
    },{sdkUrl,seed:manifest.endpoints[0].multiaddr,payment:manifest.payment,bytes:[...manifestBytes],publicBytes:[...publicBytes],content:[...content],visibility});
    assert.equal(result.address,encrypted.address);assert.equal(result.knownSize,content.length);assert.equal(result.creatorSize,1);
    assert.deepEqual(errors,[]);assert.deepEqual(consoleErrors,[]);assert.ok(wasmHashes.length>0&&wasmHashes.every(x=>x===source.wasmSha256));
    summary.phases.push({visibility,...result,sha256:sha(content),wasmHashes,pageErrors:errors,consoleErrors});
    console.log(JSON.stringify(summary.phases.at(-1))); await context.close();
  }
  await writeFile('/private/tmp/pr6-main-browser-summary.json',JSON.stringify(summary,null,2)+'\n');
}finally{await browser.close();}
