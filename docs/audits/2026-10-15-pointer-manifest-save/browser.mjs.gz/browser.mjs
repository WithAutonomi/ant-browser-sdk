import { chromium } from '/Users/mick/RustroverProjects/ant-client-wasm-large-files/ant-core/browser-tests/node_modules/playwright/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root='/Users/mick/RustroverProjects/ant-browser-sdk-pr6-20261015';
const info=await(await fetch('http://127.0.0.1:39970/api/info')).json();
const manifest=await(await fetch('http://127.0.0.1:39970/api/browser-manifest.json')).json();
assert.equal(info.evm.network,'local-anvil');
assert.ok(['localhost','127.0.0.1'].includes(new URL(info.evm.rpc_url).hostname));
const provenance=JSON.parse(await readFile(`${root}/src/wasm/source.json`,'utf8'));
const browser=await chromium.launch({headless:true,args:['--force-fieldtrials=WebRTC-NoSdpMangleUfrag/Enabled/']});
try {
 const page=await browser.newPage(); const pageErrors=[],wasmHashes=[];
 page.on('pageerror',error=>pageErrors.push(error.message));
 page.on('console',message=>{if(message.type()==='log')console.log(message.text());});
 page.on('response',async r=>{if(new URL(r.url()).pathname.endsWith('.wasm'))wasmHashes.push(createHash('sha256').update(await r.body()).digest('hex'));});
 await page.goto('http://127.0.0.1:39971',{waitUntil:'networkidle'});
 const result=await page.evaluate(async({root,manifest,rpc})=>{
  const sdk=await import(`/@fs${root}/dist/index.js`);
  const {createEthersPaymentProvider}=await import(`/@fs${root}/dist/ethers.js`);
  const assert=(value,message)=>{if(!value)throw Error(message);};
  const payment=createEthersPaymentProvider({privateKey:'0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',rpcUrl:rpc});
  const expectedPaymentNetwork={chainId:manifest.payment.chain_id,paymentTokenAddress:manifest.payment.payment_token_address,paymentVaultAddress:manifest.payment.payment_vault_address};
  const connected=await sdk.AutonomiClient.connectNetwork({id:'api-probe',seeds:manifest.endpoints.map(e=>e.multiaddr),payment:expectedPaymentNetwork},{payment});
  // Match upstream's devnet harness pacing: nodes close sessions above 16 requests/s.
  // Local Anvil confirms instantly, unlike a normal wallet confirmation.
  const pacedMethods=new Set(['upload','streamAndSave','getPointer','resolvePointer','pointerFinality','createPointer','updatePointer','transferPointer','resumePointer']);
  const client=new Proxy(connected,{get(target,key){const value=Reflect.get(target,key,target);if(typeof value!=='function')return value;return pacedMethods.has(key)?async(...args)=>{await new Promise(resolve=>setTimeout(resolve,1500));return value.apply(target,args);}:value.bind(target);}});
  const opfs=await navigator.storage.getDirectory();
  const directory=await opfs.getDirectoryHandle('sdk-api-probe',{create:true});
  const files=[];const phases=[];
  try {
   for(const visibility of ['public','private']){
    const content=Uint8Array.from({length:13056},(_,i)=>(i*37+19)%256);
    const uploaded=await client.upload(content,{name:`${visibility}.bin`,visibility,paymentMode:'single'});
    files.push(uploaded.file);
    const entry=visibility==='public'?{kind:'public',address:uploaded.file.address,path:'folder/public.bin',size:1}:{kind:'embedded',dataMap:uploaded.file.dataMap,path:'folder/private.bin',size:1};
    const created=await sdk.createManifest({name:'exports',entries:[entry]});
    const decoded=await sdk.decodeManifest(created.bytes); const parsed=await sdk.parseManifestLink(created.link);
    assert(parsed.kind==='manifest'&&parsed.manifest.entries[0].address===decoded.entries[0].address,'manifest link mismatch');
    if(visibility==='private')assert(decoded.entries[0].knownSize===content.length,'derived size');
    const handle=await directory.getFileHandle(`${visibility}.bin`,{create:true});
    let picked=false;
    window.showSaveFilePicker=async()=>{picked=true;return handle;};
    const saved=await client.streamAndSave(decoded.entries[0],{suggestedName:`${visibility}.bin`});
    const actual=new Uint8Array(await(await handle.getFile()).arrayBuffer());
    assert(picked&&saved.bytesWritten===content.length&&actual.every((n,i)=>n===content[i])&&actual.length===content.length,'stream save bytes');
    assert(saved.hash===uploaded.file.blake3,'stream save hash');
    phases.push({visibility,bytes:saved.bytesWritten,hash:saved.hash,linkRecommended:created.linkRecommended,manifestBytes:created.bytes.length,manifestBase64:btoa(String.fromCharCode(...created.bytes))});
    console.log(`files ${visibility} passed`);
   }
   const address=files[0].address;
   const owner=crypto.getRandomValues(new Uint8Array(32)),recipient=crypto.getRandomValues(new Uint8Array(32));
   const pointer=await sdk.pointerAddress(owner),recipientPointer=await sdk.pointerAddress(recipient);
   const journals={};
   const persist=key=>async value=>{const file=await directory.getFileHandle(`${key}.json`,{create:true});const writable=await file.createWritable();await writable.write(value);await writable.close();journals[key]=value;};
   assert(await client.getPointer(pointer)===null,'missing pointer');
   const first=await client.createPointer({ownerSeed:owner,kind:'chunk',target:address,onCheckpoint:persist('first')});
   assert(first.pointer.counter==='0'&&first.pointer.address===pointer,'create');
   assert((await client.getPointer(pointer)).stateId===first.pointer.stateId,'get');
   assert((await client.resolvePointer(pointer)).target===address,'resolve');
   const second=await client.updatePointer({ownerSeed:owner,kind:'chunk',target:address,onCheckpoint:persist('second')});
   assert(second.pointer.counter==='1','update');
   const open=await client.pointerFinality(pointer);assert(open.status==='open'&&open.counter==='1','open finality');
   await client.createPointer({ownerSeed:recipient,kind:'chunk',target:address,onCheckpoint:persist('recipient')});
   const transferred=await client.transferPointer({ownerSeed:owner,recipient:recipientPointer,onCheckpoint:persist('transfer')});
   assert(transferred.pointer.counter==='18446744073709551615','full width final counter');
   const finality=await client.pointerFinality(pointer);assert(finality.status==='final'&&finality.majority.transferredTo===recipientPointer,'finality');
   assert((await client.resolvePointer(pointer)).target===address,'transfer resolution');
   const stored=await client.resumePointer(journals.transfer,{onCheckpoint:persist('transfer-retry')});
   assert(stored.stateId===transferred.pointer.stateId,'paid proof replay');
   console.log('pointer create/update/transfer/finality passed');
   const recoveryOwner=crypto.getRandomValues(new Uint8Array(32)); let payCount=0;
   const interrupted={...payment,pay:async(...args)=>{payCount++;await payment.pay(...args);throw Error('probe: lost confirmation after real transaction');}};
   let failed;
   try{await client.createPointer({ownerSeed:recoveryOwner,kind:'chunk',target:address,payment:interrupted,onCheckpoint:persist('interrupted')});}catch(error){failed=error;}
   assert(failed instanceof sdk.PointerError&&failed.checkpoint,'recoverable failure');
   const journal=JSON.parse(failed.checkpoint);assert(journal.submissions.length>0&&!journal.paid,'broadcast checkpoint');
   const recovered=await client.resumePointer(failed.checkpoint,{payment:interrupted,onCheckpoint:persist('recovered')});
   assert(payCount===1&&recovered.address===await sdk.pointerAddress(recoveryOwner),'no repayment');
   assert((await client.getPointer(recovered.address)).stateId===recovered.stateId,'recovered stored state');
   const recoveredJournal=JSON.parse(journals.recovered);
   phases.push({recoveryFixture:{prepared:recoveredJournal.prepared,receipt:recoveredJournal.receipt,paid:recoveredJournal.paid}});
   phases.push({pointers:{address:pointer,created:first.pointer.counter,updated:second.pointer.counter,transferred:transferred.pointer.counter,finality,paidRetry:stored.stateId,recovered:recovered.address,payCount}});
   console.log('pointer broadcast recovery passed');
   // A caller-supplied writable is cancelled without buffering or leaving a lock.
   const controller=new AbortController();let aborts=0;
   const stream=new WritableStream({write(){controller.abort();},abort(){aborts++;}});
   let cancelled=false;try{await client.streamAndSave(files[0],{destination:stream,signal:controller.signal});}catch(error){cancelled=error.name==='AbortError';}
   assert(cancelled&&!stream.locked&&aborts===1,'stream cancellation cleanup');
   phases.push({streamCancellation:{cancelled,aborts,locked:stream.locked}});
   return phases;
  }finally{client.close();await opfs.removeEntry('sdk-api-probe',{recursive:true});}
 },{root,manifest,rpc:info.evm.rpc_url});
 const recovery=result.find(entry=>entry.recoveryFixture); await writeFile('/tmp/sdk-api-pointer-fixture.json',JSON.stringify(recovery.recoveryFixture)); result.splice(result.indexOf(recovery),1);
 for(const entry of result.filter(entry=>entry.manifestBase64)){await writeFile(`/tmp/sdk-api-${entry.visibility}.ant`,Buffer.from(entry.manifestBase64,'base64'));delete entry.manifestBase64;}
 assert.deepEqual(pageErrors,[]);assert.ok(wasmHashes.length>0&&wasmHashes.every(hash=>hash===provenance.wasmSha256));
 const summary={browser:browser.version(),wasm:provenance,node:'26129a2611cac08f9f53a557f91fb8806b40a1cc',result,pageErrors,wasmHashes};
 await writeFile('/tmp/sdk-api-browser-summary.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
}finally{await browser.close();}
